namespace Script
{
    public partial class VuserClass
    {
        public int vuser_init()
        {
			if (false)
			{		
				// PROD
								
				lr.start_transaction("EFL");
				lr.end_transaction("EFL", lr.PASS);
				
				lr.start_transaction("HELANDTAG");
				lr.end_transaction("HELANDTAG", lr.PASS);
				
				lr.start_transaction("SHAREPOINT_EXTRA");
				lr.end_transaction("SHAREPOINT_EXTRA", lr.PASS);
				
				lr.start_transaction("EU_DLR");
				lr.end_transaction("EU_DLR", lr.PASS);
				
				lr.start_transaction("HESSEN");
				lr.end_transaction("HESSEN", lr.PASS);
				
				lr.start_transaction("HESSENDRIVE");
				lr.end_transaction("HESSENDRIVE", lr.PASS);
				
				lr.start_transaction("KARRIERE_POLIZEI");
				lr.end_transaction("KARRIERE_POLIZEI", lr.PASS);
				
				lr.start_transaction("ONLINEWACHE_POLIZEI");
				lr.end_transaction("ONLINEWACHE_POLIZEI", lr.PASS);
								
				lr.start_transaction("POLIZEI_HESSEN");
				lr.end_transaction("POLIZEI_HESSEN", lr.PASS);
				
				lr.start_transaction("EVERGABE");
				lr.end_transaction("EVERGABE", lr.PASS);
				
				lr.start_transaction("HOCHWASSER_PORTAL");
				lr.end_transaction("HOCHWASSER_PORTAL", lr.PASS);
				
				// TESTING 
								
				// lr.start_transaction("_DATA_NA_TEST");
				// lr.end_transaction("_DATA_NA_TEST", lr.PASS);
				
				// lr.start_transaction("_FAIL_TEST");
				// lr.end_transaction("_FAIL_TEST", lr.PASS);				
     		}
        	return 0;
        }
    }
}

