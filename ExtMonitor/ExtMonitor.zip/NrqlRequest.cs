using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;

namespace Script
{
    internal class NrqlRequest
    {
        private static string _emptyResponse =
            "{" +
            "  \"data\": {" +
            "    \"actor\": {" +
            "      \"account\": {" +
            "        \"nrql\": {" +
            "          \"rawResponse\": {" +
            "            \"metadata\": {" +
            "              \"accounts\": [" +
            "                0" +
            "              ]," +
            "              \"beginTime\": \"1970-1-1T00:00:00Z\"," +
            "              \"beginTimeMillis\": 0," +
            "              \"contents\": [" +
            "                {" +
            "                  \"function\": \"NO_DATA\"," +
            "                  \"limit\": 0," +
            "                  \"order\": {" +
            "                    \"column\": \"NO_DATA\"," +
            "                    \"descending\": true" +
            "                  }" +
            "                }" +
            "              ]," +
            "              \"endTime\": \"0-0-0T0:0:0Z\"," +
            "              \"endTimeMillis\": 0," +
            "              \"eventType\": \"NO_DATA\"," +
            "              \"eventTypes\": [" +
            "                \"SyntheticRequest\"" +
            "              ]," +
            "              \"guid\": \"NO_DATA\"," +
            "              \"messages\": []," +
            "              \"openEnded\": true," +
            "              \"rawCompareWith\": \"\"," +
            "              \"rawSince\": \"NO_DATA\"," +
            "              \"rawUntil\": \"NO_DATA\"," +
            "              \"routerGuid\": \"NO_DATA\"" +
            "            }," +
            "            \"performanceStats\": {" +
            "              \"exceedsRetentionWindow\": false," +
            "              \"inspectedCount\": 0," +
            "              \"matchCount\": 0," +
            "              \"omittedCount\": 0," +
            "              \"wallClockTime\": 0" +
            "            }," +
            "            \"results\": [" +
            "              {" +
            "                \"events\": [" +
            "                  {" +
            "                    \"timestamp\": 0," +
            "                    \"responseBodySize\": 0," +
            "                    \"id\": \"NO_DATA\"," +
            "                    \"durationBlocked\": 0," +
            "                    \"entityGuid\": \"NO_DATA\"," +
            "                    \"locationLabel\": \"NO_DATA\"," +
            "                    \"responseStatus\": \"NO_DATA\"," +
            "                    \"durationSSL\": 0," +
            "                    \"durationConnect\": 0," +
            "                    \"duration\": 0," +
            "                    \"monitorName\": \"NO_DATA\"," +
            "                    \"isAjax\": false," +
            "                    \"verb\": \"NO_DATA\"," +
            "                    \"requestBodySize\": 0," +
            "                    \"host\": \"NO_DATA\"," +
            "                    \"minion\": \"NO_DATA\"," +
            "                    \"location\": \"NO_DATA\"," +
            "                    \"path\": \"NO_DATA\"," +
            "                    \"jobId\": \"NO_DATA\"," +
            "                    \"minionId\": \"NO_DATA\"," +
            "                    \"externalResource\": false," +
            "                    \"port\": 0," +
            "                    \"contentType\": \"NO_DATA\"," +
            "                    \"monitorId\": \"NO_DATA\"," +
            "                    \"durationSend\": 0," +
            "                    \"responseHeaderSize\": 0," +
            "                    \"hierarchicalURL\": \"NO_DATA\"," +
            "                    \"durationReceive\": 0," +
            "                    \"contentCategory\": \"NO_DATA\"," +
            "                    \"checkId\": \"NO_DATA\"," +
            "                    \"responseCode\": 0," +
            "                    \"durationDNS\": 0," +
            "                    \"domain\": \"NO_DATA\"," +
            "                    \"URL\": \"NO_DATA\"," +
            "                    \"requestHeaderSize\": 0," +
            "                    \"serverIPAddress\": \"0.0.0.0\"," +
            "                    \"durationWait\": 0" +
            "                  }" +
            "                ]" +
            "              }" +
            "            ]" +
            "          }," +
            "          \"results\": [" +
            "            {" +
            "              \"timestamp\": 0," +
            "              \"responseBodySize\": 0," +
            "              \"id\": \"NO_DATA\"," +
            "              \"durationBlocked\": 0," +
            "              \"entityGuid\": \"NO_DATA\"," +
            "              \"locationLabel\": \"NO_DATA\"," +
            "              \"responseStatus\": \"NO_DATA\"," +
            "              \"durationSSL\": 0," +
            "              \"durationConnect\": 0," +
            "              \"duration\": 0," +
            "              \"monitorName\": \"NO_DATA\"," +
            "              \"isAjax\": false," +
            "              \"verb\": \"NO_DATA\"," +
            "              \"requestBodySize\": 0," +
            "              \"host\": \"NO_DATA\"," +
            "              \"minion\": \"NO_DATA\"," +
            "              \"location\": \"NO_DATA\"," +
            "              \"path\": \"NO_DATA\"," +
            "              \"jobId\": \"NO_DATA\"," +
            "              \"minionId\": \"NO_DATA\"," +
            "              \"externalResource\": false," +
            "              \"port\": 0," +
            "              \"contentType\": \"NO_DATA\"," +
            "              \"monitorId\": \"NO_DATA\"," +
            "              \"durationSend\": 0," +
            "              \"responseHeaderSize\": 0," +
            "              \"hierarchicalURL\": \"NO_DATA\"," +
            "              \"durationReceive\": 0," +
            "              \"contentCategory\": \"NO_DATA\"," +
            "              \"checkId\": \"NO_DATA\"," +
            "              \"responseCode\": 0," +
            "              \"durationDNS\": 0," +
            "              \"domain\": \"NO_DATA\"," +
            "              \"URL\": \"NO_DATA\"," +
            "              \"requestHeaderSize\": 0," +
            "              \"serverIPAddress\": \"NO_DATA\"," +
            "              \"durationWait\": 0" +
            "            }" +
            "          ]" +
            "        }" +
            "      }" +
            "    }" +
            "  }" +
            "}";
        
        private static string _template = 
            "{" + 
                "\"query\":\" {\\n " +   
                    "actor {\\n " +
                        "account(id: PLACEHOLDER_ACCOUNT_ID) {\\n " +
                            @" nrql(query: \""PLACEHOLDER_QUERY\"") {\n " +
                                "PLACEHOLDER_FIELDS" + 
                            "}\\n " +
                        "}\\n " +
                    "}\\n " +
                "}\", " +
                "\"variables\":\"\"" +
            "}";
        internal string NrqlRequestString = "";
        internal string StatusDesc = "";
        internal int StatusCode = -99;
        internal string ResponseString = "";
        internal Dictionary<string, string> ParsedData = new Dictionary<string, string>();
        
        internal NrqlRequest(string accountId, string apiKey, string baseQuery, string monitorId, string[] fields, string proxyUsername, string proxyDomain, string proxyUserPassword)
        {
            Create(accountId, baseQuery, monitorId, fields);
            try
            {
                Post(apiKey, proxyUsername, proxyDomain, proxyUserPassword);
            }
            catch
            {
                ResponseString = _emptyResponse;
            }
            finally
            {
                if (StatusCode != 200 || !StatusDesc.Equals("OK"))
                {
                    ResponseString = _emptyResponse;
                }
                else if (!ResponseString.Contains("responseCode"))
                {
                    ResponseString = _emptyResponse;
                }
                ParseResult();
            }
        }
        
        private void ParseResult()
        {
            ParsedData.Add("monitor name", Regex.Match(ResponseString, "(?<=\"monitorName\":\\s*\")[\\s\\S]*?(?=\")").Value);
            ParsedData.Add("monitor location", Regex.Match(ResponseString, "(?<=\"locationLabel\":\\s*\")[\\s\\S]*?(?=\")").Value);
            ParsedData.Add("monitor response status", Regex.Match(ResponseString, "(?<=\"responseStatus\":\\s*\")[\\s\\S]*?(?=\")").Value);
            ParsedData.Add("monitor response code", Regex.Match(ResponseString, "(?<=\"responseCode\":\\s*)\\S+?(?=[,\\}\\s])").Value);
            ParsedData.Add("timestamp accessed", new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).AddMilliseconds(long.Parse(Regex.Match(ResponseString, "(?<=\"timestamp\":\\s*)\\S+?(?=[,\\}\\s])").Value)).ToLocalTime().ToString());
            ParsedData.Add("monitored content type", Regex.Match(ResponseString, "(?<=\"contentType\":\\s*\")[\\s\\S]*?(?=\")").Value);
            ParsedData.Add("monitored url", Regex.Match(ResponseString, "(?<=\"URL\":\\s*\")[\\s\\S]*?(?=\")").Value);
            ParsedData.Add("monitored host", Regex.Match(ResponseString, "(?<=\"host\":\\s*\")[\\s\\S]*?(?=\")").Value);
            ParsedData.Add("monitored domain", Regex.Match(ResponseString, "(?<=\"domain\":\\s*\")[\\s\\S]*?(?=\")").Value);
            ParsedData.Add("monitored server IP", Regex.Match(ResponseString, "(?<=\"serverIPAddress\":\\s*\")[\\s\\S]*?(?=\")").Value);
            ParsedData.Add("response time (ms)", Regex.Match(ResponseString, "(?<=\"duration\":\\s*)\\S+?(?=[,\\}\\s])").Value);
            ParsedData.Add("response time SSL (ms)", Regex.Match(ResponseString, "(?<=\"durationSSL\":\\s*)\\S+?(?=[,\\}\\s])").Value);
            ParsedData.Add("response time connect (ms)", Regex.Match(ResponseString, "(?<=\"durationConnect\":\\s*)\\S+?(?=[,\\}\\s])").Value);
            ParsedData.Add("response time receive (ms)", Regex.Match(ResponseString, "(?<=\"durationReceive\":\\s*)\\S+?(?=[,\\}\\s])").Value);
            ParsedData.Add("response time DNS (ms)", Regex.Match(ResponseString, "(?<=\"durationDNS\":\\s*)\\S+?(?=[,\\}\\s])").Value);
            ParsedData.Add("response time wait (ms)", Regex.Match(ResponseString, "(?<=\"durationWait\":\\s*)\\S+?(?=[,\\}\\s])").Value);
            ParsedData.Add("response time send (ms)", Regex.Match(ResponseString, "(?<=\"durationSend\":\\s*)\\S+?(?=[,\\}\\s])").Value);
            ParsedData.Add("response header size", Regex.Match(ResponseString, "(?<=\"responseHeaderSize\":\\s*)\\S+?(?=[,\\}\\s])").Value);
            ParsedData.Add("response body size", Regex.Match(ResponseString, "(?<=\"responseBodySize\":\\s*)\\S+?(?=[,\\}\\s])").Value);
        }

        private void Post(string apiKey, string proxyUsername, string proxyDomain, string proxyUserPassword)
        {
            // Set TLS config
            ServicePointManager.Expect100Continue = true;                
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            
            // Add Proxy
            WebProxy proxy = new WebProxy();
            proxy.Credentials = new NetworkCredential(proxyUsername, proxyUserPassword, proxyDomain);
            proxy.Address = new Uri("http://internetproxy.intern.hessen.de:8080");

            // Create Webrequest
            WebRequest request = WebRequest.Create("https://api.eu.newrelic.com/graphql");
            request.Method = WebRequestMethods.Http.Post;
            request.ContentType = "application/json";
            request.Headers.Add("API-Key", apiKey);
            request.Proxy = proxy;
            request.Timeout = 10000;
            
            // Create data to post
            byte[] bytePostData = Encoding.UTF8.GetBytes(NrqlRequestString);
            request.ContentLength = bytePostData.Length;
            
            // Get the request stream.
            Stream dataStream = request.GetRequestStream();
            // Write the data to the request stream.
            dataStream.Write(bytePostData, 0, bytePostData.Length);
            // Close the Stream object.
            dataStream.Close();
            
            // Get the response.
            WebResponse response = request.GetResponse();
            // Get the stream containing content returned by the server.
            dataStream = response.GetResponseStream();
            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(dataStream);
            // Read the content and ave result to object variable
            ResponseString = reader.ReadToEnd();
            // Clean up the streams.
            reader.Close();
            dataStream.Close();
            
            // Retrieve exitCode from reponse before closing it
            StatusDesc = ((HttpWebResponse) response).StatusDescription;
            StatusCode = (int)((HttpWebResponse) response).StatusCode;
            response.Close();
        }

        private void Create(string accountId, string query, string monitorId, string[] fields)
        {
            string nrqlQuery = query.Replace("''", "'" + monitorId + "'");
            StringBuilder sb = new StringBuilder();
            foreach (string var in fields)
            {
                sb.Append(var + " \\n ");
            }
            NrqlRequestString = _template.Replace("PLACEHOLDER_FIELDS", sb.ToString()).Replace("PLACEHOLDER_QUERY", nrqlQuery).Replace("PLACEHOLDER_ACCOUNT_ID", accountId);
        }
    }
}