using System;
using System.IO;
using System.Security.Cryptography;

namespace Script
{
    internal static class Cryptor
    {
        //
        private static Rijndael _alg = Rijndael.Create();
        private static byte[] _key = new byte[32] { 118, 123, 23, 17, 161, 152, 35, 68, 126, 213, 16, 115, 68, 217, 58, 108, 56, 218, 5, 78, 28, 128, 113, 208, 61, 56, 10, 87, 187, 162, 233, 38 };
        private static byte[] _iv = new byte[16] { 33, 241, 14, 16, 103, 18, 14, 248, 4, 54, 18, 5, 60, 76, 16, 191};
        //	
        
        internal static string DecryptStringFromBytesToBase64String(string cipherTextBase64)
        {
            _alg.Key = _key;
            _alg.IV = _iv;
            //
            //
        	byte[] cipherText = Convert.FromBase64String(cipherTextBase64);        		
            if (cipherText == null || cipherText.Length <= 0)
            {
                throw new ArgumentNullException("cipherTextBase64");            	
            }
			//
            string plaintext = null;
            //
            ICryptoTransform decryptor = _alg.CreateDecryptor(_alg.Key, _alg.IV);
            //
            using (MemoryStream msDecrypt = new MemoryStream(cipherText))
            {
                using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                {
                    using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                    {
                        plaintext = srDecrypt.ReadToEnd();
                    }
                }
            }
            return plaintext;
        }
    }
}