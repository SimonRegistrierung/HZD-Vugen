namespace Script
{
    public partial class VuserClass
    {
        public int vuser_end()
        {
            return 0;
        }
    }
}
