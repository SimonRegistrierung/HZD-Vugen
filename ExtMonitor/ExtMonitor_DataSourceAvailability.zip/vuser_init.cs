namespace Script
{
    public partial class VuserClass
    {
        public int vuser_init()
        {
			if (false)
			{
				lr.start_transaction("DATA_SOURCE_AVAIL");
				lr.end_transaction("DATA_SOURCE_AVAIL", lr.PASS);		
     		}
        	return 0;
        }
    }
}

