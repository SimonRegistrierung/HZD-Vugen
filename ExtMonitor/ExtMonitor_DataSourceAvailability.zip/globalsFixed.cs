namespace Script
{
    public partial class VuserClass
    {
        private LoadRunner.LrApi lr = new LoadRunner.LrApi(); // Initialize LR-API Interface 
        public void DATASET_XML(int arg)
        {
        }
    }
}
