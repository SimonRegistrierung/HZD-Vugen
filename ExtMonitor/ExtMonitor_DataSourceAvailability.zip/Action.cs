//  ---------------------------------------------
// 	Loadrunner-Script f�r Abruf von NewRelic-Daten mittels API
// 	dient zum Abruf externer Monitoring-Daten von NewRelic 
//  durch eine Standard-NSM-Probe von SVM
//  Geschrieben im C#/DotNet-Protokoll

// 	Dr. Simon Beste 
//	01.08.2024
//	HZD
//  ---------------------------------------------

namespace Script 
{
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
	using System;
	using System.Linq;
	using System.Collections;
	using System.Collections.Generic;
	using System.IO;
	using System.Net;
	using System.Text;
	using System.Text.RegularExpressions;
        
    public partial class VuserClass 
    {
        private static readonly string accountId = @"4013575";
        private static readonly string apiKey = @"sQ2V4mSxVxowtW1ilik32Y1LX0eO/Bi/gAsE5qvqdQsTql0TVDmcLgA3ij39wfQL";
        private static readonly string[] fields = new string[]{ "results" }; // @"results;rawResponse";
        private static readonly string baseQuery = @"SELECT * FROM SyntheticRequest SINCE 5 MINUTES AGO WHERE monitorId = ''";
		//
		private static readonly string proxyUserPassword = @"ygdLIjcRtMhDfhrSGiL9hg==";
		//
		private static readonly int maxLogfileSize = 100*1000*1000; // size in mBytes
		    	
        public int Action()
        {
        	string logDir = @"C:\ExtMonitor\";
        	if (!Directory.Exists(logDir))
        	{
        		Directory.CreateDirectory(logDir);
        	}
			string logfilePath = @"C:\ExtMonitor\" + lr.eval_string("{Transaction_Name}") + "_vugen_out.log";
            //
            // CREATE NRQL REQUEST & DECRYPT PASSWORD WITH STATIC ENCRYPTOR CLASS
            NrqlRequest nrqlRequest = new NrqlRequest(
            	accountId,
                Cryptor.DecryptStringFromBytesToBase64String(apiKey), 
                baseQuery, 
                lr.eval_string("{MonitorId}"), 
                fields, 
                "insmprbusr",
                "itshessen",
                Cryptor.DecryptStringFromBytesToBase64String(proxyUserPassword)
            );
            //
            // DISPLAY STATUS OF REQUEST AND RESPONSE
            lr.output_message("\n\n=== " + lr.eval_string("{Transaction_Name}") + " - API REQUEST ===\n" + nrqlRequest.NrqlRequestString + "\n ");
            lr.output_message("\n\n=== " + lr.eval_string("{Transaction_Name}") + " - API RESPONSE ===\nrequest status desc:           " + nrqlRequest.StatusDesc + "\nrequest status code:           " + nrqlRequest.StatusCode + "\n ");
            //
            // DISPLAY RAW DATA FOR DEBUGGING
            lr.output_message("\n\n=== " + lr.eval_string("{Transaction_Name}") + " - API RAW DATA ===\n" + nrqlRequest.ResponseString + "\n ");
            //
            // PREPARE STRING BUILD AND APPEND LOGFILE HEADER
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(
            	"================================================\n" +
            	"   API Request Time:    " + DateTime.Now.ToString().Replace(" ", " - ") + "\n" +
                "   API Request Status:  " + nrqlRequest.StatusCode + "\n" +
                "================================================"
            );
            //
            // ITERATE THROUGH PARSED RESULTS DICTIONARY AND APPEND PARSED RESULTS TO STRING BUILDER
            foreach (KeyValuePair<string, string> dataChunk in nrqlRequest.ParsedData)
            {
            	string currentStr = dataChunk.Key + ":" +  new String(' ', 30 - dataChunk.Key.ToString().Length) + dataChunk.Value;
            	sb.AppendLine(currentStr);
            }
            //
            // WRITE TO LOG FILE
            sb.AppendLine("\n" );
            if (File.Exists(logfilePath) && LogfileArchiver.IsCriticalSize(maxLogfileSize, logfilePath))
            {
            	LogfileArchiver.Archive(logfilePath, logfilePath.Replace(".log", "_") + DateTime.Now.ToString("yyyy-MM-dd") + ".zip");
            	File.Delete(logfilePath);
            	File.WriteAllText(logfilePath, sb.ToString());
            }
            else
            {
            	File.AppendAllText(logfilePath, sb.ToString());            	
            }
            lr.output_message("\n\n=== " + lr.eval_string("{Transaction_Name}") + " - API PARSED DATA ===\n" + sb.ToString() + "\n ");
            //
        	// GENERATE RESPONSE TIME FOR TRANSACTIONS
        	KeyValuePair<string, string> monitorResponseCodeStr = nrqlRequest.ParsedData.Where(entry => entry.Key == @"monitor response code").FirstOrDefault();
        	KeyValuePair<string, string> responseTimeStr = nrqlRequest.ParsedData.Where(entry => entry.Key == @"response time (ms)").FirstOrDefault();
        	int monitorResponseCode;
        	double responseTime;
        	try 
        	{        		
        		monitorResponseCode = Int32.Parse(monitorResponseCodeStr.Value);
        		if (responseTimeStr.Value.Length >= 4)
        		{
        			responseTime = Convert.ToDouble(responseTimeStr.Value.Substring(0, 3)) / 1000;
        		}
        		else
        		{
        			responseTime = Convert.ToDouble(responseTimeStr.Value) / 1000;
        		}
        	}
        	catch (Exception ignore)
        	{
	    		monitorResponseCode = 0;
	    		responseTime = 0;
        	}
            //
        	// SET FINAL TRANSACTION RESULT WITH CORRESPONDING RESPONSE TIME
        	if (nrqlRequest.StatusCode == 200)
        	{
        		lr.output_message("\n\n=== " + lr.eval_string("{Transaction_Name}") + " - API PARSED RESULT: PASS ===\n ");
        		lr.set_transaction(lr.eval_string("{Transaction_Name}"), responseTime, lr.PASS);
        	}
        	else 
        	{
        		lr.output_message("\n=== " + lr.eval_string("{Transaction_Name}") + " - API PARSED RESULT: FAIL ===\n ");
				lr.set_transaction(lr.eval_string("{Transaction_Name}"), responseTime, lr.FAIL);
        	}
        	//
        	// CONTROL SCRIPT PACING, WAIT 500 MS
        	lr.think_time(0.5);
			return 0;
		}
	}
}