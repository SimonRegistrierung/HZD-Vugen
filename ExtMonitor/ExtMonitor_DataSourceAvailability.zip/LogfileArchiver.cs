using System;
using System.IO;
using Ionic.Zip;

namespace Script
{
    internal static class LogfileArchiver
    {
    	internal static void Archive(string logfilePath, string zipfilePath)
    	{    	
    		byte[] emptyzip = new byte[]{80,75,5,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
			FileStream fs = File.Create(zipfilePath);
			fs.Write(emptyzip, 0, emptyzip.Length);
			fs.Flush();
			fs.Close();
			//
			FileInfo fileInfo = new FileInfo(logfilePath);
			Ionic.Zip.ZipFile zipFile = new Ionic.Zip.ZipFile();
  			zipFile.AddFile(fileInfo.FullName, fileInfo.Name);
  			zipFile.Save(zipfilePath);
    	}
    	
    	internal static bool IsCriticalSize(int maxSize, string logfilePath)
        {
    		if (new FileInfo(logfilePath).Length > maxSize)
    		{
    			return true;
    		}
    		return false;
        }
    }
}