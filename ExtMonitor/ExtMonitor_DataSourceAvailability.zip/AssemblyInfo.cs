using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// attributes. Change the attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")] 
[assembly: AssemblyProduct("")] 
[assembly: AssemblyCopyright("")] 
[assembly: AssemblyTrademark("")] 

// Version information for an assembly consists of the following four arguments:
//
//      Major Version, Minor Version , Build Number,  Revision
//
// You can specify all the values or you can accept the default the build and revision numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.0.*")]
