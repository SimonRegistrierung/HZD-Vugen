//---------------------------------------------
//Class	Name		  : SharepointModule
//Purpose			  : Stellt die Zugriffsart f�r den Sharepointzugriff bereit und bietet eine strukturierte, tabellierte Datenlieferung der Sharepoint Rohdaten. 
//						Dient als Sharepoint-Tabellen-API
//---------------------------------------------
//Part of Script 	  : Servicekatalog_Exporter
//Script Description  : Exportiert den Servicekatalog mit den Feldern ID, techn. Servicename und SLA in eine CSV
//Author:			  : Dr. Simon Beste
//---------------------------------------------

using System;
using System.Net; 
using System.Security;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Microsoft.SharePoint.Client;

namespace Script
{
    public static class SharepointModule
    {
        internal static List<ServiceObject> GetList(string url)
        {
            ClientContext clientContext = new ClientContext(url);
            //
            List oList = clientContext.Web.Lists.GetByTitle("Servicekatalog");
            //
            CamlQuery camlQuery = new CamlQuery();
            camlQuery.ViewXml = "<View></View>";
            ListItemCollection listItemCollection = oList.GetItems(camlQuery);
            //
            clientContext.Load(listItemCollection);
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; // IMPORTANT FOR BPM REPLAY BECAUSE OF OLD DOTNET IMPLMEMENTATION: 
        																		// ADD TLS1.2 TO THE SECURITY PROTOCOL USED!
        																		// THIS IS NOT NEEDED WHEN REPLAYING THE SCRIPT IN VUGEN
            clientContext.ExecuteQuery();
            //
            List<ServiceObject> sharepointList = new List<ServiceObject>();
            foreach (ListItem listItem in listItemCollection)
            {
                ServiceObject currentServiceObject = new ServiceObject(-1, "", "");
                foreach (KeyValuePair<string, object> kvp in listItem.FieldValues)
                {
                    // Console.WriteLine(kvp.Key + "\t" + kvp.Value);
                    //
                    // filter out all objects without SLA
                    if (null != kvp.Key && null != kvp.Value)
                    {
                        if (kvp.Key.Equals("ID"))
                        {
                            currentServiceObject.Id = int.Parse(kvp.Value.ToString());
                        }
                        else if (kvp.Key.Equals("techn_x002e__x0020_Servicename"))
                        {
                            if (kvp.Value.Equals("-"))
                            {
                                currentServiceObject.TechName = "";
                            }
                            else
                            {
                                currentServiceObject.TechName = Regex.Replace(kvp.Value.ToString(), @"([^A-Za-z0-9])+", "_").ToUpper();
                            }
                        }
                        else if (kvp.Key.Equals("Verf_x00fc_gbarkeit"))
                        {
                            currentServiceObject.SLA = kvp.Value.ToString().Replace(",", ".");
                        }
                        //
                    }
                }
                sharepointList.Add(currentServiceObject);
            }
            return sharepointList;
        }
    }
}
