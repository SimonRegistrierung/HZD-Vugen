//---------------------------------------------
//Class Name	      : ServiceObject
//Purpose			  : Custom Object, welches die ben�tigten Properties aus der Sharepoint-Liste enh�lt
//---------------------------------------------
//Part of Script 	  : Servicekatalog_Exporter
//Script Description  : Exportiert den Servicekatalog mit den Feldern ID, techn. Servicename und SLA in eine CSV
//Author:			  : Dr. Simon Beste
//---------------------------------------------

namespace Script
{
    public class ServiceObject
    {
        public int Id { get; set; }
        public string TechName { get; set; }
        public string SLA { get; set; }
        //
        
        internal ServiceObject(
            int id, 
            string techName, 
            string sla
        )
        {
            Id = id;
            TechName = techName.Trim();
            SLA = sla.Trim();
        }
        
        internal string[] GetPropsAsString()
        {
            return new string[]
            {
                Id.ToString(),
                TechName,
                SLA,
            };
        }
    }
}

