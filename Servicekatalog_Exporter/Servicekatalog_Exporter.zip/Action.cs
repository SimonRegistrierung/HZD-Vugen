//---------------------------------------------
//Script Title        : Servicekatalog_Exporter
//Script Description  : Exportiert den Servicekatalog mit den Feldern ID, techn. Servicename und SLA in eine CSV
//Author:			  : Dr. Simon Beste
//---------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
//using LoadRunner;
//using Mercury.LoadRunner.DotNetProtocol.Replay;

namespace Script
{
    public partial class VuserClass
    {
        private static string _url = @"https://gremien.intern.hessen.de/its/HZD-Servicekatalog_publiziert";
        private static string _outPath = @"C:\service_katalog_export.csv";
        private static string _netPath = @"\\10.6.1.81\daten$\SVM\Servicekatalog_Export_NSM_Portal\";
        private static byte _minCount = 5;
        
        private static List<ServiceObject> _serviceList = new List<ServiceObject>();
        
        public int Action()
        {
        	lr.start_transaction("ALL");
            //
        	_serviceList = SharepointModule.GetList(_url);
        	lr.output_message("Fetching service list successful");
        	lr.output_message("Service list length: " + _serviceList.Count);
        	//
            if (_serviceList.Count > _minCount)
            {
            	WriteToFile();
        		lr.output_message("File length length: " + File.ReadAllLines(_outPath).Length);
        		lr.end_transaction("ALL", lr.AUTO);
            }
            else
            {
            	lr.end_transaction("ALL", lr.FAIL);
            }
    		//
			return 0;
        }
        
        private static void WriteToFile()
        {
            string header =
                "ID," +
                "technischer Servicename," +
                "SLA";
            //
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(header);
            foreach (ServiceObject serviceObject in _serviceList)
            {
                sb.AppendLine(string.Join(",", serviceObject.GetPropsAsString()));
            }
            //
            File.WriteAllText(_outPath, sb.ToString());
            File.Copy(_outPath, _outPath.Replace(@"C:\", _netPath), true);
            File.Copy(_outPath, _outPath.Replace(@".csv", "_" + DateTime.Now.ToString("yyyy-MM-dd") + ".csv").Replace(@"C:\", _netPath), true);
            //
        }
    }
}
