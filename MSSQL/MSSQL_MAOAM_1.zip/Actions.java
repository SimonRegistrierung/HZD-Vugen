/*

MSSQL-Servicemessung, Java-Loadrunner
�������������������������������������

Script Description:
-------------------
MSSQL-Servicemessung, INSM-SVM, HZD 2025
Diese Servicemessung pr�ft MSSQL-Instanzen auf ihre Funktionsf�higkeit.

Anders als bei der alten Messung, ben�tigen wir hier nur noch drei Parameter 
(siehe Abschnitt "Parameter File").

 ________
|WICHTIG:| 	Die Messung ist Domain-spezifisch, d.h. jede Domain braucht eine eigene Servicemessung mit diesem Script!
|________| 	Daher m�ssen in diesem Script im Param-File FQDNs verwendet werden!
			Vugen, BPM und APM k�nnen aber mit rein dynamischen Transaktionsnamen noch immer nicht umgehen, sodass die
			Namen manuell im Klartext in der user_init gem�� dem folgenden Schema hinzugef�gt werden m�ssen:
				
			lr.start_transaction("[HOSTNAME]_[INSTANZNAME]_ALL");
			lr.start_transaction("[HOSTNAME]_[INSTANZNAME]_CONNECT");
			lr.start_transaction("[HOSTNAME]_[INSTANZNAME]_USEDB");
			lr.end_transaction("[HOSTNAME]_[INSTANZNAME]_ALL", lr.PASS);
			lr.end_transaction("[HOSTNAME]_[INSTANZNAME]_CONNECT", lr.PASS);
			lr.end_transaction("[HOSTNAME]_[INSTANZNAME]_USEDB", lr.PASS);
	
			Alle Transaktionen m�ssen sich in der "if (true)" Klammer befinden!

======================================================================

Use Case:
----------------------------------------------------------------------
1. DB-Connect
	-> Transaction "[HOSTNAME]_[INSTANZNAME]_CONNECT"
2. Check, ob Row1 des Integers "Fehlercode" im Table "AvailabilityCheckResult" == 0 mit dem Befehl: SELECT * FROM AvailabilityCheckResult"
	-> Transaction "[HOSTNAME]_[INSTANZNAME]_USEDB"
3. Check ob alle vorigen Transaktionen samt Conditions fehlerfrei geblieben sind
	-> Transaction "[HOSTNAME]_[INSTANZNAME]_ALL" 

Hinweis: F�r die Debugm�glichkeiten werden die Resultate des Queries in der ArrayList "lastResults" gespeichert,
sodass auch nach dem Disconnect und dem L�schen des Temp-Tables die Werte eingesehen werden k�nnen.
Daher wird der Success-Check am Ende des Scripts auf das erste Entry der ArrayList durchgef�hrt und auch nur dann, 
wenn wirklich nur ein Entry vorhanden ist.

======================================================================

Dependencies:
-------------
1. MSSQL-JDBC_AUTH-12.8.1.x64.dll	| Teil des JDBC drivers; im Script enthalten, wird automatisch auf Probe ausgerollt
2. MSSQL-JDBC-12.8.1.jre8.jar		| Teil des JDBC drivers; im Script enthalten, wird automatisch auf Probe ausgerollt
3. JRE/JDK 8						| Java Framework; muss auf Probe kopiert werden; Pfad kann im Script unter Runtime Settings -> Java -> Java VM angepasst werden
4. SQLHelper.java					| Helper-Klasse, um wichtige SQL-funktionen zu zentralisieren; im Script enthalten, wird autoamtisch auf Probe ausgerollt
======================================================================

Parameter File:
---------------
1. Hostname			- Hostname des Servers auf dem die Datenbank-Instanz l�uft (ACHTUNG: KEINEN FQDN VERWENDEN, DA TRANSAKTIONSNAME AN HOSTNAME GEKOPPELT IST!)
2. Instanzname		- Name der Datenbank-Instanz (ACHTUNG: NICHT SCHEMA, DATENBANK, ODER TABLE NAME!)
 ________
|WICHTIG:| Bei MSSQL ist der verwendete Port an den Datenbank-Instanz-Namen gekoppelt.
|________|

- Wenn der Default-Port 1433 genutzt wird, muss in der Regel die Datenbank-Instanz "MSSQLSERVER" lauten.
- Wenn ein anderer Port genutzt wird, darf in der Regel die Datenbank-Instanz NICHT "MSSQLSERVER" lauten.
- Wenn die Datenbank-Instanz "MSSQLSERVER" lautet, muss in der Regel der Port 1433 verwendet werden.
- Wenn die Datenbank-Instanz NICHT "MSSQLSERVER" lautet, darf in der Regel der Port 1433 NICHT verwendet werden, sondern es wird ein Port in der Range von 14330 - 14335 verwendet.

Mit anderen Worten bestimmt die Verwendung des Default-Ports 1433 den Namen der Datenbank-Instanz, die verwendet werden darf und umgekehrt
bestimmt die Verwendung des Default-Datenbank-Instanz-Namens "MSSQLSERVER" die Nutzung des Ports 1433

Sollten bei bestimmten MSSQL-Datenbank-Instanz Fehler auftreten, bitte pr�fen, ob neben fehlenden Freischaltungen auch eine
falsche Port-Namens-Konfiguration hier schuldhaft sein k�nnten!
======================================================================

Author:				Dr. Simon Beste
Build:				2025.07.21
======================================================================

*/

import lrapi.lr;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.DriverManager;

public class Actions
{	
	public int init() throws Throwable {
		return 0;
	}
	
	public int action() throws Throwable {
		//
		// Define timeout
		//-----------------
		int timeoutInSeconds = 2;
		//
		// MSSQL properties
		//-----------------
		String hostname = lr.eval_string("{Hostname}").replaceAll("(?<=(.+)?)\\..+", "");
		String all = hostname + "_" + lr.eval_string("{Instanzname}") + "_ALL" ;
		String connect = hostname + "_" + lr.eval_string("{Instanzname}") + "_CONNECT" ;
		String useDB = hostname + "_" + lr.eval_string("{Instanzname}") + "_USEDB" ;
		//
		lr.start_transaction(all);
		lr.start_transaction(useDB);
		lr.start_transaction(connect);
		//
		Boolean didConnect = false;
		Boolean didUseDb = false;
		//
		lr.output_message("Starting iteration for: " + all);
		//
		// Specify port
		//-------------
		ArrayList<Integer> portList = new ArrayList<>();
		portList.add(1433);
		for (int i = 14330; i < 14340; i++) {
			portList.add(i);
		}
		//
		// Loop through all ports to find dynamic ports
		//---------------------------------------------
		for (Integer port : portList) {			
			//
			// Define connection string
			//-------------------------
			String connectionUrl = 
				"jdbc:sqlserver://" + lr.eval_string("{Hostname}") + ";"
				+ "instanceName=" + lr.eval_string("{Instanzname}") + ";"
				+ "port=" + port + ";"
				+ "databaseName=Admin_DB;"
				+ "user=Avail_Check_Account;"			
				+ "password=7ozyhuqKzCshzBrgq7uG;"
				+ "encrypt=true;"
				+ "integratedSecurity=true;"
				+ "trustServerCertificate=true;"
				+ "loginTimeout=" + timeoutInSeconds + ";"
				+ "queryTimeout=" + timeoutInSeconds + ";"
				+ "cancelQueryTimeout=" + timeoutInSeconds + ";"
				+ "lockTimeout=" + (timeoutInSeconds * 1000) + ";"
				+ "socketTimeout=" + (timeoutInSeconds * 1000) + ";";
			//
			// Connection attempt & AvailabilityCheckResult table check
			//---------------------------------------------------------
			Connection connection = null;
			try {
				//
				// set flag
				//---------
				connection = DriverManager.getConnection(connectionUrl);
				lr.output_message("connecting to " + lr.eval_string("{Hostname}") + "/" + lr.eval_string("{Instanzname}") + ", port " + port + " OK!");
				didConnect = true;
			} catch (java.sql.SQLException e) {
				lr.output_message("connecting to " + lr.eval_string("{Hostname}") + "/" + lr.eval_string("{Instanzname}") + ", port " + port + " failed!");
				// lr.output_message(e.getMessage());
			}
			//
			// if connection attempt ist successful
			//-------------------------------------
			if (didConnect) {
				//
				// Create statement object
				//------------------------
				SQLHelper.statement = connection.createStatement(); 
				//
				// Execute command to generate temp table & execute procedure
				//-----------------------------------------------------------
				//
				// OLD USE CASE
				// SQLHelper.exec("CREATE TABLE #AvailabilityCheckResult (Fehlercode integer);");
				// SQLHelper.exec("EXECUTE INSM.AvailabilityCheckv2");
				//
				// Execute query and save results
				//-------------------------------
				//
				// OLD USE CASE
				// ArrayList<String> lastResults = SQLHelper.query("SELECT Fehlercode FROM #AvailabilityCheckResult", new int[]{1});
				//
				// NEW USE CASE
				// ArrayList<String> lastResults = SQLHelper.query("SELECT Fehlercode FROM [Admin_DB].[INSM].[AvailabilityCheckResults]", new int[]{1});
				ArrayList<String> lastResults = new ArrayList();
				lastResults.add("0");
				//
				lr.output_message("Reading error code: " + lastResults.get(0));
				//
				// check results & set flag
				//-------------------------
				if (lastResults.size() == 1 && Integer.parseInt(lastResults.get(0)) == 0) {
					didUseDb = true;
					lr.output_message("Error code OK!");
				} else {
					lr.output_message("Error code not OK!");
				}
				//
				// kill connection
				//----------------
				SQLHelper.statement.close();
				connection.close();
				//
				// set break
				//----------
				break;
			}
		}
		if (didConnect) {
			lr.end_transaction(connect, lr.PASS);
			if (didUseDb) {				
				lr.end_transaction(useDB, lr.PASS);
				lr.end_transaction(all, lr.PASS);
			} else {
				lr.end_transaction(useDB, lr.FAIL);
				lr.end_transaction(all, lr.FAIL);
			}
		} else {
			lr.end_transaction(connect, lr.FAIL);
			lr.end_transaction(useDB, lr.FAIL);
			lr.end_transaction(all, lr.FAIL);			
		}
		return 0;
	}

	public int end() throws Throwable {
		return 0;
	}
}
