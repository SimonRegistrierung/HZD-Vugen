/*

Description:
------------
MSSQL script helper class that contains methods which are used in conjunction with the JDBC driver.
Serves as a repository to centralize all SQL methods and keep the main Loadrunner script more reable and clean.

======================================================================

Author:				Dr. Simon Beste
Build:				2025.04.02
======================================================================

 */

import lrapi.lr;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.DriverManager;

public class SQLHelper
{
	//
	// MSSQL driver objects which are instantiated in Actions class
	// ------------------------------------------------------------
	public static Statement statement;
	public static ResultSet resultSet;
	
	//
	// Simple method that executes a command on the DB
	// --------------------------------------------------------------------------------------
	public static void exec(String execStr) throws Throwable {
		try {
			Boolean result = statement.execute(execStr);
			lr.output_message("Statement execution '" + execStr + "' includes resultSet: " + result.toString());
		} catch (Exception e) {
			lr.error_message("Could not execute statement: " + execStr);
			lr.error_message(e.getMessage());
		}
	}
	
	//
	// Simple method that returns all lines and columns of a query as a string list
	// ----------------------------------------------------------------------------
	public static ArrayList<String> query(String queryStr, int[] columns) throws Throwable {
		ArrayList<String> lastResults = new ArrayList<String>();
		try {
			resultSet = statement.executeQuery(queryStr);
	        //
	        int line = 1;
	        while (resultSet.next()) {
	        	for (int column : columns) {
	        		lastResults.add(resultSet.getString(column));
					lr.output_message("lastResults '" + queryStr + "' column " + column + ", line " + line + ": " + resultSet.getString(column) + ", list size is now " + lastResults.size());
	        	}
	        	line++;
	        }
		} catch (Exception e) {
			lr.error_message("Could not send query statement: " + queryStr);
			lr.error_message(e.getMessage());
		}
        return lastResults;
	}
}
