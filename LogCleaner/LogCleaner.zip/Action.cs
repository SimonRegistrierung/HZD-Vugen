//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 
//---------------------------------------------

using LoadRunner;
using System.IO;
using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Script
{
    public partial class VuserClass
    {
    	string logFilePath = @"C:\HPBSM\Scripte\test\logfile.txt";
    	string logFilePath2 = @"C:\HPBSM\Scripte\test\logfile2.txt";
    	
        public int Action()
        {
        	FileInfo file = new FileInfo(logFilePath);
        	lr.output_message(file.Length.ToString());
        	
        	for (int i = 0; i < 10; i++)
        	{
        		string timestamp = DateTime.Now.ToString("yyyy-MM-dd\thh:mm:ss" + "\n");
        		File.AppendAllText(logFilePath, timestamp);
        		Thread.Sleep(1000);
        	}
        	
        	CleanLog();
            return 0;
        }
        
        public void CleanLog()
        {
        	int maxLogfileSize = 200; // size in mBytes
        	// int maxLogfileSize = 50*1000*1000; // size in mBytes
        	//
        	List<string> newString = File.ReadAllLines(logFilePath).OfType<string>().ToList();
        	int totalSize = 0;
        	//
        	int maxLine = 0;
    		for (int i = newString.ToArray().Length - 1; i >= 0; i--)
        	{
    			totalSize += newString[i].Length;
    			if (totalSize > maxLogfileSize)
	    		{
        			break;
	    		}
    			maxLine++;
        	}
    		//
        	StringBuilder sb = new StringBuilder();
    		for (int i = newString.ToArray().Length - maxLine; i < newString.ToArray().Length; i++)
        	{
    			sb.AppendLine(newString[i]);
    		}
    		//
    		File.WriteAllText(logFilePath2, sb.ToString());
        }
    }
}
