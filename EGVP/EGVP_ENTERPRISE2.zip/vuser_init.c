vuser_init()
{
	if (FALSE)
	{
		lr_start_transaction("Async");
		lr_start_transaction("sendAsynchroniousMessage");
		lr_start_transaction("asynchroniousMessageSent");
		lr_start_transaction("commitSentMessage_async");
		lr_start_transaction("getUncommittedMessages_async");
		lr_start_transaction("receiveMessage_async");
		lr_start_transaction("commitReceivedMessage_async");
		
		lr_end_transaction("Async", LR_PASS);
		lr_end_transaction("sendAsynchroniousMessage", LR_PASS);
		lr_end_transaction("asynchroniousMessageSent", LR_PASS);
		lr_end_transaction("commitSentMessage_async", LR_PASS);
		lr_end_transaction("getUncommittedMessages_async", LR_PASS);
		lr_end_transaction("receiveMessage_async", LR_PASS);
		lr_end_transaction("commitReceivedMessage_async", LR_PASS);
	}
	
	return 0;
}
