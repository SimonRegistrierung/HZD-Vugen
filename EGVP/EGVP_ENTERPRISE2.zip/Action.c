Action()
{
	int globalerror = 0;
	
	int result_sendAsynchroniousMessageRequest = 0;
	int result_asynchroniousMessageSentRequest = 0;
	int result_commitSentMessageRequest = 0;
	int result_getUncommittedMessageIDsRequest = 0;
	int result_receiveMessageRequest = 0;
	int result_commitReceivedMessageRequest = 0;

	char* sender = "DE.Justiz.3bfe09b1-2d64-4ae3-8a9f-93d3178d93f2.f261";
	char* receiver = "DE.Justiz.fd1e855a-7bb3-4595-8514-f734d8d20348.e26b";
	
	char* wsdl = "http://enterprise.justiz.hessen.de:8080/EGVP-WS/EGVP-WebServiceMtom?wsdl";
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	lr_save_string(sender, "sender");
	lr_save_string(receiver, "receiver");
	lr_save_string(wsdl, "wsdl");
	
	lr_message("sender: %s",lr_eval_string("{sender}"));
	lr_message("receiver: %s",lr_eval_string("{receiver}"));
	lr_message("wsdl: %s",lr_eval_string("{wsdl}"));

	lr_start_transaction("Async");
	
	lr_start_transaction("sendAsynchroniousMessage");
	result_sendAsynchroniousMessageRequest = sendAsynchroniousMessageRequest(0);
	if (result_sendAsynchroniousMessageRequest == 0)
	{
		lr_end_transaction("sendAsynchroniousMessage", LR_PASS);
	}
	else
	{
		lr_end_transaction("sendAsynchroniousMessage", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_sendAsynchroniousMessageRequest: %i", result_sendAsynchroniousMessageRequest);
	lr_output_message("====================================");
	
	lr_think_time(10);
	
	lr_start_transaction("asynchroniousMessageSent");
	result_asynchroniousMessageSentRequest = asynchroniousMessageSentRequest(0);
	if (result_asynchroniousMessageSentRequest == 0)
	{
		lr_end_transaction("asynchroniousMessageSent", LR_PASS);
	}
	else
	{
		lr_end_transaction("asynchroniousMessageSent", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_asynchroniousMessageSentRequest: %i", result_asynchroniousMessageSentRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("commitSentMessage_async");
	result_commitSentMessageRequest = commitSentMessageRequest(0);
	if (result_commitSentMessageRequest == 0)
	{
		lr_end_transaction("commitSentMessage_async", LR_PASS);
	}
	else
	{
		lr_end_transaction("commitSentMessage_async", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_commitSentMessageRequest: %i", result_commitSentMessageRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("getUncommittedMessages_async");
	result_getUncommittedMessageIDsRequest = getUncommittedMessageIDsRequest(0);
	if (result_getUncommittedMessageIDsRequest == 0)
	{
		lr_end_transaction("getUncommittedMessages_async", LR_PASS);
	}
	else
	{
		lr_end_transaction("getUncommittedMessages_async", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_getUncommittedMessageIDsRequest: %i", result_getUncommittedMessageIDsRequest);
	lr_output_message("====================================");
	
	lr_think_time(10);
	
	lr_start_transaction("receiveMessage_async");
	result_receiveMessageRequest = receiveMessageRequest(0);
	if (result_receiveMessageRequest == 0)
	{
		lr_end_transaction("receiveMessage_async", LR_PASS);
	}
	else
	{
		lr_end_transaction("receiveMessage_async", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_receiveMessageRequest: %i", result_receiveMessageRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("commitReceivedMessage_async");
	result_commitReceivedMessageRequest = commitReceivedMessageRequest(0);
	if (result_commitReceivedMessageRequest == 0)
	{
		lr_end_transaction("commitReceivedMessage_async", LR_PASS);
	}
	else
	{
		lr_end_transaction("commitReceivedMessage_async", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_commitReceivedMessageRequest: %i", result_commitReceivedMessageRequest);
	lr_output_message("====================================");
	
	globalerror = 
		result_sendAsynchroniousMessageRequest +
		result_asynchroniousMessageSentRequest + 
		result_commitSentMessageRequest + 
		result_getUncommittedMessageIDsRequest + 
		result_receiveMessageRequest + 
		result_commitReceivedMessageRequest;
	
	lr_output_message("====================================");
	lr_output_message("GLOBAL ERROR CODE: %i", globalerror);
	lr_output_message("====================================");
	
	if (globalerror == 0)
	{
		lr_end_transaction("Async", LR_PASS);
	}
	else
	{
		lr_end_transaction("Async", LR_FAIL);
	}
	return 0;
}

int sendAsynchroniousMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 5; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=sa_id",
		"RegExp=<customID>(.+?)</customID>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);

		web_reg_save_param_regexp(
			"ParamName=RC",
			"RegExp=<returnCode>(.+?)</returnCode>",
			"NotFound=warning",
			SEARCH_FILTERS,
			LAST);
		
		web_custom_request("sendAsynchroniousMessageRequest",
		"Method=POST",
		"URL={wsdl}",
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
		"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		   "<soapenv:Header>"       
		   "</soapenv:Header>"
		        "<soapenv:Body>"
		        "<urn:sendAsynchroniousMessageRequest>"
					"<userID>{sender}</userID>"
					"<messageType>Testnachricht</messageType>"
					"<receiverID>{receiver}</receiverID>"
					"<receiverKey>USER_ID</receiverKey>"
					"<subject>Monitoring_NSM_asynchron</subject>"
			        "<!--Optional:-->"
			        "<signMessage>FALSE</signMessage>"
			        "<!--Optional:-->"
			        "<visualXML>cid:935139199178</visualXML>"
			        "<!--Optional:-->"
			        "<visualXSL>cid:801271932342</visualXSL>"
			        "<!--Zero or more repetitions:-->"
			        "<attachments>"
			           "<data>cid:499641380441</data>"
			           "<name>xjustiz_nachricht.xml</name>"
			        "</attachments>"
				"</urn:sendAsynchroniousMessageRequest>"
	          "</soapenv:Body>"
		    "</soapenv:Envelope>",  
	    LAST);
		
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int asynchroniousMessageSentRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 5; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
	
		web_reg_save_param_regexp(
			"ParamName=na_id",
			"RegExp=<messageID>(.+?)</messageID>",
			"NotFound=warning",
			SEARCH_FILTERS,
			LAST);
		
		web_custom_request("asynchroniousMessageSentRequest",
			"Method=POST",
			"URL={wsdl}",
			"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
			"<soapenv:Header>"       
			"</soapenv:Header>"
			    "<soapenv:Body>"
					"<urn:asynchroniousMessageSentRequest>"
					"<userID>{sender}</userID>"
					"<customID>{sa_id}</customID>"
				"</urn:asynchroniousMessageSentRequest>"     
			      "</soapenv:Body>"
			"</soapenv:Envelope>", 
	    LAST);
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int commitSentMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 5; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
	
		web_custom_request("commitSentMessageRequest",
		"Method=POST",
		"URL={wsdl}",
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
		"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
	       "<soapenv:Header>"       
	       "</soapenv:Header>"
	            "<soapenv:Body>"
	      		"<urn:commitSentMessageRequest>"
					"<userID>{sender}</userID>"
					"<messageID>{na_id}</messageID>"
			"</urn:commitSentMessageRequest>"    
	              "</soapenv:Body>"
	        "</soapenv:Envelope>",    
	    LAST);
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int getUncommittedMessageIDsRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 5; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
	
		web_custom_request("getUncommittedMessageIDsRequest",
			"Method=POST",
			"URL={wsdl}",
			"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		       "<soapenv:Header>"       
		       "</soapenv:Header>"
		            "<soapenv:Body>"
		      		"<urn:getUncommittedMessageIDsRequest>"
						"<userID>{receiver}</userID>"
					"</urn:getUncommittedMessageIDsRequest>"     
		              "</soapenv:Body>"
		        "</soapenv:Envelope>",    
	    LAST);
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int receiveMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 5; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
		
		web_custom_request("receiveMessageRequest",
			"Method=POST",
			"URL={wsdl}",
			"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		       "<soapenv:Header>"       
		       "</soapenv:Header>"
		            "<soapenv:Body>"
			            "<urn:receiveMessageRequest>"
							"<userID>{receiver}</userID>"
							"<messageID>{na_id}</messageID>"
						"</urn:receiveMessageRequest>"  
	              	"</soapenv:Body>"
	        "</soapenv:Envelope>",
		    LAST);
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int commitReceivedMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 5; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);

		web_custom_request("commitReceivedMessageRequest",
		   "Method=POST",
		   "URL={wsdl}",
		   "Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		       "<soapenv:Header>"       
		       "</soapenv:Header>"
		            "<soapenv:Body>"
		            "<urn:commitReceivedMessageRequest>"
						"<userID>{receiver}</userID>"
						"<messageID>{na_id}</messageID>"
					"</urn:commitReceivedMessageRequest>"  
		              "</soapenv:Body>"
		        "</soapenv:Envelope>",
		    LAST);
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}
