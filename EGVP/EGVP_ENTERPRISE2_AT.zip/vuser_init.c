vuser_init()
{
	if (FALSE)
	{
		lr_start_transaction("AT_Async");
		lr_start_transaction("AT_sendAsynchroniousMessage");
		lr_start_transaction("AT_asynchroniousMessageSent");
		lr_start_transaction("AT_commitSentMessage_async");
		lr_start_transaction("AT_getUncommittedMessages_async");
		lr_start_transaction("AT_receiveMessage_async");
		lr_start_transaction("AT_commitReceivedMessage_async");
		
		lr_end_transaction("AT_Async", LR_PASS);
		lr_end_transaction("AT_sendAsynchroniousMessage", LR_PASS);
		lr_end_transaction("AT_asynchroniousMessageSent", LR_PASS);
		lr_end_transaction("AT_commitSentMessage_async", LR_PASS);
		lr_end_transaction("AT_getUncommittedMessages_async", LR_PASS);
		lr_end_transaction("AT_receiveMessage_async", LR_PASS);
		lr_end_transaction("AT_commitReceivedMessage_async", LR_PASS);
	}
	
	return 0;
}
