vuser_init()
{
	if (FALSE)
	{
		lr_start_transaction("AT_Sync");
		lr_start_transaction("AT_sendSynchroniousMessage");
		lr_start_transaction("AT_getUncommittedMessages_sync");
		lr_start_transaction("AT_receiveMessage_sync");
		lr_start_transaction("AT_commitReceivedMessage_sync");
		lr_start_transaction("AT_searchReceiver");
		
		lr_end_transaction("AT_Sync", LR_PASS);
		lr_end_transaction("AT_sendSynchroniousMessage", LR_PASS);
		lr_end_transaction("AT_getUncommittedMessages_sync", LR_PASS);
		lr_end_transaction("AT_receiveMessage_sync", LR_PASS);
		lr_end_transaction("AT_commitReceivedMessage_sync", LR_PASS);
		lr_end_transaction("AT_searchReceiver", LR_PASS);
	}
	return 0;
}
