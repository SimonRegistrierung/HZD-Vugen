Action()
{
	char * filename = "c:\\HPBSM\\Scripte\\EGVP_Enterprise_AT\\zip.txt";
	char * access_mode = "w+";
	long file_stream;
	
	int globalerror = 0;
	
	int result_sendSynchroniousMessageRequest = 0;
	int result_getUncommittedMessageIDsRequest = 0;
	int result_receiveMessageRequest = 0;
	int result_commitReceivedMessageRequest = 0;
	int result_searchReceiver = 0;
	
	char* sender = "safe-st1-1485988789547-011462995";
	char* receiver = "safe-st1-1485988793415-011462997";
	
	char* wsdl = "http://enterprise-at.justiz.hessen.de:8080/EGVP-WS/EGVP-WebServiceMtom?wsdl";
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	lr_save_string(sender, "sender");
	lr_save_string(receiver, "receiver");
	lr_save_string(wsdl, "wsdl");
	
	lr_message("sender: %s",lr_eval_string("{sender}"));
	lr_message("receiver: %s",lr_eval_string("{receiver}"));
	lr_message("wsdl: %s",lr_eval_string("{wsdl}"));

	lr_start_transaction("AT_Sync");
	
	lr_start_transaction("AT_sendSynchroniousMessage");
	result_sendSynchroniousMessageRequest = sendSynchroniousMessageRequest(0);
	if (result_sendSynchroniousMessageRequest == 0)
	{
		lr_end_transaction("AT_sendSynchroniousMessage", LR_PASS);
	}
	else
	{
		lr_end_transaction("AT_sendSynchroniousMessage", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_sendSynchroniousMessageRequest: %i", result_sendSynchroniousMessageRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("AT_getUncommittedMessages_sync");
	result_getUncommittedMessageIDsRequest = getUncommittedMessageIDsRequest(0);
	if (result_getUncommittedMessageIDsRequest == 0)
	{
		lr_end_transaction("AT_getUncommittedMessages_sync", LR_PASS);
	}
	else
	{
		lr_end_transaction("AT_getUncommittedMessages_sync", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_getUncommittedMessageIDsRequest: %i", result_getUncommittedMessageIDsRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("AT_receiveMessage_sync");
	result_receiveMessageRequest = receiveMessageRequest(0);
	if (result_receiveMessageRequest == 0)
	{
		lr_end_transaction("AT_receiveMessage_sync", LR_PASS);
	}
	else
	{
		lr_end_transaction("AT_receiveMessage_sync", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_receiveMessageRequest: %i", result_receiveMessageRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("AT_commitReceivedMessage_sync");
	result_commitReceivedMessageRequest = commitReceivedMessageRequest(0);
	if (result_commitReceivedMessageRequest == 0)
	{
		lr_end_transaction("AT_commitReceivedMessage_sync", LR_PASS);
	}
	else
	{
		lr_end_transaction("AT_commitReceivedMessage_sync", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_commitReceivedMessageRequest: %i", result_commitReceivedMessageRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("AT_searchReceiver");
	result_searchReceiver = searchReceiver(0);
	if (result_searchReceiver == 0)
	{
		lr_end_transaction("AT_searchReceiver", LR_PASS);
	}
	else
	{
		lr_end_transaction("AT_searchReceiver", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_searchReceiver: %i", result_searchReceiver);
	lr_output_message("====================================");
	
	globalerror = 
		result_sendSynchroniousMessageRequest +
		result_getUncommittedMessageIDsRequest +
		result_receiveMessageRequest +
		result_commitReceivedMessageRequest;
	
	lr_output_message("====================================");
	lr_output_message("GLOBAL ERROR CODE: %i", globalerror);
	lr_output_message("====================================");
	
	if (globalerror == 0)
	{
		lr_end_transaction("AT_Sync", LR_PASS);
	}
	else
	{
		lr_end_transaction("AT_Sync", LR_FAIL);
	}
	return 0;
}

int sendSynchroniousMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
		
		web_custom_request("sendSynchroniousMessageRequest",
		   "Method=POST",
		   "URL={wsdl}",
		   "Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		       "<soapenv:Header>"       
		       "</soapenv:Header>"
		            "<soapenv:Body>"
			            "<urn:sendSynchroniousMessageRequest>"
							 "<userID>{sender}</userID>"
					         "<messageType>Testnachricht</messageType>"
					         "<receiverID>{receiver}</receiverID>"
					         "<receiverKey>USER_ID</receiverKey>"
					         "<subject>Monitoring_NSM_synchron</subject>"
					         "<!--Optional:-->"
					         "<signMessage>FALSE</signMessage>"
					         "<!--Optional:-->"
					         "<visualXML>cid:829435190685</visualXML>"
					         "<!--Optional:-->"
					         "<visualXSL>cid:1352479721739</visualXSL>"
					         "<!--Zero or more repetitions:-->"
					         "<attachments>"
					            "<data>cid:1624969371934</data>"
					            "<name>xjustiz_nachricht.xml</name>"
					         "</attachments>"
						"</urn:sendSynchroniousMessageRequest>"	     
		            "</soapenv:Body>"
		        "</soapenv:Envelope>",  
	    LAST);		
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(5);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int getUncommittedMessageIDsRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
	
		web_custom_request("getUncommittedMessageIDsRequest",
		   "Method=POST",
		   "URL={wsdl}",
		   "Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
			"<soapenv:Header>"       
			"</soapenv:Header>"
			    "<soapenv:Body>"
					"<urn:getUncommittedMessageIDsRequest>"
					"<userID>{sender}</userID>"
				"</urn:getUncommittedMessageIDsRequest>"     
			      "</soapenv:Body>"
			"</soapenv:Envelope>",  
	    LAST);		
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(5);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int receiveMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
		
		web_reg_save_param_regexp(
			"ParamName=na_id",
			"RegExp=<messageID>(.+?)</messageID>",
			"NotFound=warning",
			SEARCH_FILTERS,
			LAST);
	
		web_reg_save_param_regexp(
			"ParamName=zip",
			"RegExp=<messageZIP>(.+?)</messageZIP>",
			"NotFound=warning",
			SEARCH_FILTERS,
			LAST);
			
		web_custom_request("receiveMessageRequest",
		   "Method=POST",
		   "URL={wsdl}",
		   "Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		       "<soapenv:Header>"       
		       "</soapenv:Header>"
		            "<soapenv:Body>"
					"<urn:receiveMessageRequest>"
						"<userID>{receiver}</userID>"
					"</urn:receiveMessageRequest>"     
		              "</soapenv:Body>"
		        "</soapenv:Envelope>",  
		    LAST);		
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(5);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int commitReceivedMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);

		web_custom_request("commitReceivedMessageRequest",
		"Method=POST",
		"URL={wsdl}",
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
		"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		   "<soapenv:Header>"       
		   "</soapenv:Header>"
		        "<soapenv:Body>"
				"<urn:commitReceivedMessageRequest>"
					"<userID>{receiver}</userID>"
					"<messageID>{na_id}</messageID>"
				"</urn:commitReceivedMessageRequest>"  
		          "</soapenv:Body>"
		    "</soapenv:Envelope>",  
		LAST); 	
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(5);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

searchReceiver(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
	
		web_custom_request("searchReceiver",
	  	 "Method=POST",
	  	 "URL={wsdl}",
	  	 "Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
		"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
	       "<soapenv:Header>"       
	       "</soapenv:Header>"
	       "<soapenv:Body>" 		
				"<urn:searchReceiverRequest>"
					"<userID>{receiver}</userID>"
					"<searchCriteria>"
						"<userID searchMode=\"CONTAINS\">{sender}</userID>"
					"</searchCriteria>"
				"</urn:searchReceiverRequest>"
	      	"</soapenv:Body>"
	    "</soapenv:Envelope>",     
	         
	    LAST);
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(5);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}
