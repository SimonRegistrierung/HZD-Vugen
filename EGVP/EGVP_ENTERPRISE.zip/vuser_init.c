vuser_init()
{
	if (FALSE)
	{
		lr_start_transaction("Sync");
		lr_start_transaction("sendSynchroniousMessage");
		lr_start_transaction("getUncommittedMessages_sync");
		lr_start_transaction("receiveMessage_sync");
		lr_start_transaction("commitReceivedMessage_sync");
		lr_start_transaction("searchReceiver");
		
		lr_end_transaction("Sync", LR_PASS);
		lr_end_transaction("sendSynchroniousMessage", LR_PASS);
		lr_end_transaction("getUncommittedMessages_sync", LR_PASS);
		lr_end_transaction("receiveMessage_sync", LR_PASS);
		lr_end_transaction("commitReceivedMessage_sync", LR_PASS);
		lr_end_transaction("searchReceiver", LR_PASS);
		
		lr_start_transaction("JURZMAZSEGV09");
		lr_start_transaction("JURZMAZSEGV10");
		lr_start_transaction("JURZMAZSEGV11");
		lr_start_transaction("JURZMAZSEGV12");
		lr_start_transaction("JURZMAZSEGV13");
		lr_start_transaction("JURZMAZSEGV14");
		lr_start_transaction("JURZMAZSEGV15");
		lr_start_transaction("JURZMAZSEGV16");
		lr_start_transaction("JURZMAZSEGV17");
		
		lr_end_transaction("JURZMAZSEGV09", LR_PASS);
		lr_end_transaction("JURZMAZSEGV10", LR_PASS);
		lr_end_transaction("JURZMAZSEGV11", LR_PASS);
		lr_end_transaction("JURZMAZSEGV12", LR_PASS);
		lr_end_transaction("JURZMAZSEGV13", LR_PASS);
		lr_end_transaction("JURZMAZSEGV14", LR_PASS);
		lr_end_transaction("JURZMAZSEGV15", LR_PASS);
		lr_end_transaction("JURZMAZSEGV16", LR_PASS);
		lr_end_transaction("JURZMAZSEGV17", LR_PASS);
	}
	return 0;
}
