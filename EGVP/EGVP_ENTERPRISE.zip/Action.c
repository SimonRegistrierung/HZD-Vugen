Action()
{
	char * filename = "c:\\HPBSM\\Scripte\\EGVP_Enterprise\\zip.txt";
	char * access_mode = "w+";
	long file_stream;
	
	int globalerror = 0;
	
	int result_sendSynchroniousMessageRequest = 0;
	int result_getUncommittedMessageIDsRequest = 0;
	int result_receiveMessageRequest = 0;
	int result_commitReceivedMessageRequest = 0;
	int result_searchReceiver = 0;
	int result_searchReceiverCluster = 0;
	
	char* sender = "DE.Justiz.155e3f18-f054-4875-b7c7-0d508998243a.14c4";
	char* receiver = "DE.Justiz.894b8302-2b85-4a26-9e20-18cc58f6bd25.0359";
	
	char* wsdl = "http://enterprise.justiz.hessen.de:8080/EGVP-WS/EGVP-WebServiceMtom?wsdl";
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	lr_save_string(sender, "sender");
	lr_save_string(receiver, "receiver");
	lr_save_string(wsdl, "wsdl");
	
	lr_message("sender: %s",lr_eval_string("{sender}"));
	lr_message("receiver: %s",lr_eval_string("{receiver}"));
	lr_message("wsdl: %s",lr_eval_string("{wsdl}"));

	lr_start_transaction("Sync");
	
	lr_start_transaction("sendSynchroniousMessage");
	result_sendSynchroniousMessageRequest = sendSynchroniousMessageRequest(0);
	if (result_sendSynchroniousMessageRequest == 0)
	{
		lr_end_transaction("sendSynchroniousMessage", LR_PASS);
	}
	else
	{
		lr_end_transaction("sendSynchroniousMessage", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_sendSynchroniousMessageRequest: %i", result_sendSynchroniousMessageRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("getUncommittedMessages_sync");
	result_getUncommittedMessageIDsRequest = getUncommittedMessageIDsRequest(0);
	if (result_getUncommittedMessageIDsRequest == 0)
	{
		lr_end_transaction("getUncommittedMessages_sync", LR_PASS);
	}
	else
	{
		lr_end_transaction("getUncommittedMessages_sync", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_getUncommittedMessageIDsRequest: %i", result_getUncommittedMessageIDsRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("receiveMessage_sync");
	result_receiveMessageRequest = receiveMessageRequest(0);
	if (result_receiveMessageRequest == 0)
	{
		lr_end_transaction("receiveMessage_sync", LR_PASS);
	}
	else
	{
		lr_end_transaction("receiveMessage_sync", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_receiveMessageRequest: %i", result_receiveMessageRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("commitReceivedMessage_sync");
	result_commitReceivedMessageRequest = commitReceivedMessageRequest(0);
	if (result_commitReceivedMessageRequest == 0)
	{
		lr_end_transaction("commitReceivedMessage_sync", LR_PASS);
	}
	else
	{
		lr_end_transaction("commitReceivedMessage_sync", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_commitReceivedMessageRequest: %i", result_commitReceivedMessageRequest);
	lr_output_message("====================================");
	
	lr_start_transaction("searchReceiver");
	result_searchReceiver = searchReceiver(0);
	if (result_searchReceiver == 0)
	{
		lr_end_transaction("searchReceiver", LR_PASS);
	}
	else
	{
		lr_end_transaction("searchReceiver", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_searchReceiver: %i", result_searchReceiver);
	lr_output_message("====================================");
	
	lr_start_transaction("searchReceiverCluster");
	result_searchReceiverCluster = searchReceiverCluster(0);
	if (result_searchReceiverCluster == 0)
	{
		lr_end_transaction("searchReceiverCluster", LR_PASS);
	}
	else
	{
		lr_end_transaction("searchReceiverCluster", LR_FAIL);
	}
	lr_output_message("====================================");
	lr_output_message("result_searchReceiverCluster: %i", result_searchReceiverCluster);
	lr_output_message("====================================");
	
	globalerror = 
		result_sendSynchroniousMessageRequest +
		result_getUncommittedMessageIDsRequest +
		result_receiveMessageRequest +
		result_commitReceivedMessageRequest;
	
	lr_output_message("====================================");
	lr_output_message("GLOBAL ERROR CODE: %i", globalerror);
	lr_output_message("====================================");
	
	if (globalerror == 0)
	{
		lr_end_transaction("Sync", LR_PASS);
	}
	else
	{
		lr_end_transaction("Sync", LR_FAIL);
	}
	return 0;
}

int sendSynchroniousMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
		
		web_custom_request("sendSynchroniousMessageRequest",
		   "Method=POST",
		   //
		   "URL={wsdl}",
		   "Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		       "<soapenv:Header>"       
		       "</soapenv:Header>"
		          "<soapenv:Body>"
		            "<urn:sendSynchroniousMessageRequest>"
						"<userID>{sender}</userID>"
						"<messageType>Testnachricht</messageType>"
						"<receiverID>{receiver}</receiverID>"
						"<receiverKey>USER_ID</receiverKey>"
         				"<subject>Monitoring_NSM_synchron</subject>"
				        "<!--Optional:-->"
				        "<signMessage>FALSE</signMessage>"
				        "<!--Optional:-->"
				        "<visualXML>cid:829435190685</visualXML>"
				        "<!--Optional:-->"
				        "<visualXSL>cid:1352479721739</visualXSL>"
				        "<!--Zero or more repetitions:-->"
				        "<attachments>"
				           "<data>cid:1624969371934</data>"
				           "<name>xjustiz_nachricht.xml</name>"
				        "</attachments>"
					"</urn:sendSynchroniousMessageRequest>"	     
		          "</soapenv:Body>"
		        "</soapenv:Envelope>",  
	    LAST);		
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int getUncommittedMessageIDsRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
	
		web_custom_request("getUncommittedMessageIDsRequest",
		   "Method=POST",
		   //
		   "URL={wsdl}",
		   "Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
			"<soapenv:Header>"       
			"</soapenv:Header>"
			    "<soapenv:Body>"
					"<urn:getUncommittedMessageIDsRequest>"
					"<userID>{sender}</userID>"
				"</urn:getUncommittedMessageIDsRequest>"     
			      "</soapenv:Body>"
			"</soapenv:Envelope>",  
	    LAST);		
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int receiveMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
		
		web_reg_save_param_regexp(
			"ParamName=na_id",
			"RegExp=<messageID>(.+?)</messageID>",
			"NotFound=warning",
			SEARCH_FILTERS,
			LAST);
	
		web_reg_save_param_regexp(
			"ParamName=zip",
			"RegExp=<messageZIP>(.+?)</messageZIP>",
			"NotFound=warning",
			SEARCH_FILTERS,
			LAST);
			
		web_custom_request("receiveMessageRequest",
		   "Method=POST",
		   //
		   "URL={wsdl}",
		   "Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		       "<soapenv:Header>"       
		       "</soapenv:Header>"
		            "<soapenv:Body>"
					"<urn:receiveMessageRequest>"
						"<userID>{receiver}</userID>"
					"</urn:receiveMessageRequest>"     
		              "</soapenv:Body>"
		        "</soapenv:Envelope>",  
		    LAST);		
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

int commitReceivedMessageRequest(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);

		web_custom_request("commitReceivedMessageRequest",
		"Method=POST",
		//
		"URL={wsdl}",
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
		"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
		   "<soapenv:Header>"       
		   "</soapenv:Header>"
		        "<soapenv:Body>"
				"<urn:commitReceivedMessageRequest>"
					"<userID>{receiver}</userID>"
					"<messageID>{na_id}</messageID>"
				"</urn:commitReceivedMessageRequest>"  
		          "</soapenv:Body>"
		    "</soapenv:Envelope>",  
		LAST); 	
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

searchReceiver(int retry)
{
	int i;
	int result;
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
	
	for (i = 0; i < 3; i++)
	{
		web_reg_save_param_regexp(
		"ParamName=RC",
		"RegExp=<returnCode>(.+?)</returnCode>",
		"NotFound=warning",
		SEARCH_FILTERS,
		LAST);
	
		web_custom_request("searchReceiver",
	  	 "Method=POST",
		 //
	  	 "URL={wsdl}",
	  	 "Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
		"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
	       "<soapenv:Header>"       
	       "</soapenv:Header>"
	       "<soapenv:Body>" 		
				"<urn:searchReceiverRequest>"
					"<userID>{receiver}</userID>"
					"<searchCriteria>"
						"<userID searchMode=\"CONTAINS\">{sender}</userID>"
					"</searchCriteria>"
				"</urn:searchReceiverRequest>"
	      	"</soapenv:Body>"
	    "</soapenv:Envelope>",     
	         
	    LAST);
		
		result = strcmp(lr_eval_string("{RC}"), "OK");
		if(result != 0)
		{
			lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
			//lr_think_time(3);
		}
		else
		{
			lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
			break;
		}
	}
	lr_message("Return result: %i", result);
	return result;
}

searchReceiverCluster(int retry)
{	
	//constants
	#define number_of_elements 9
	#define element_length 20
	char wsdl2[200];
	
	int i;
	int u;
	int result;
	
	char transaction_names[number_of_elements][element_length] = 
	{
		"JURZMAZSEGV09",
		"JURZMAZSEGV10",
		"JURZMAZSEGV11",
		"JURZMAZSEGV12",
		"JURZMAZSEGV13",
		"JURZMAZSEGV14",
		"JURZMAZSEGV15",
		"JURZMAZSEGV16",
		"JURZMAZSEGV17"
	};
	
	web_set_timeout("CONNECT", "3");   //adjusting timeout
	web_set_timeout("RECEIVE", "3");
	web_set_timeout("STEP", "3");
	
		
	for (u = 0; u < number_of_elements; u++)
	{		
		lr_start_transaction(transaction_names[u]);

		web_reg_save_param_regexp(
			"ParamName=RC",
			"RegExp=<returnCode>(.+?)</returnCode>",
			"NotFound=warning",
			SEARCH_FILTERS,
			LAST);
		
		memset(wsdl2, 0, sizeof(wsdl2)); // resets the array
		strcat(wsdl2, "http://");
		strcat(wsdl2, transaction_names[u]);
		strcat(wsdl2, ".justiz.hessen.de:8080/EGVP-WS/EGVP-WebServiceMtom?wsdl");		
		lr_save_string(wsdl2, "wsdl2");
		
		lr_message("%s", wsdl2);
		
		for (i = 0; i < 3; i++)
		{
			web_reg_save_param_regexp(
			"ParamName=RC",
		    //
			"RegExp=<returnCode>(.+?)</returnCode>",
			"NotFound=warning",
			SEARCH_FILTERS,
			LAST);
		
			web_custom_request("searchReceiver",
				"Method=POST",
				"URL={wsdl2}",
				"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?>" 	
				"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:de:bos-bremen:egvp:ws\">"
				"<soapenv:Header>"       
				"</soapenv:Header>"
				"<soapenv:Body>" 		
					"<urn:searchReceiverRequest>"
						"<userID>DE.Justiz.3bfe09b1-2d64-4ae3-8a9f-93d3178d93f2.f261</userID>"
						"<searchCriteria>"
							"<userID searchMode=\"CONTAINS\">DE.Justiz.fd1e855a-7bb3-4595-8514-f734d8d20348.e26b</userID>"
							"<role searchMode=\"?\"></role>"
						"</searchCriteria>"
					"</urn:searchReceiverRequest>"
					"</soapenv:Body>"
				"</soapenv:Envelope>",
				LAST);
			
			result = strcmp(lr_eval_string("{RC}"), "OK");
			if(result != 0)
			{
				lr_message("Starting iteration number: %i, because of result %s", i+1, lr_eval_string("{RC}"));
				//lr_think_time(3);
			}
			else
			{
				lr_message("Ending iterations, because of result %s", lr_eval_string("{RC}"));
				break;
			}
		}
		if (result == 0)
		{
			lr_end_transaction(transaction_names[u], LR_PASS);
		}
		else
		{
			lr_end_transaction(transaction_names[u], LR_FAIL);
		}
	}
	return 0;
}