//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 2079
//---------------------------------------------

namespace Script {
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    
    
    public partial class VuserClass {
        
        public virtual int Action() {

            return 0;
        }
    }
}
