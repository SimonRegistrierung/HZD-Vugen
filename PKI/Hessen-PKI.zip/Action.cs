// ---------------------------------------------------------------
// Neu-Erstellung des Script nach Problemen mit Windows-Migration
// Umstellung auf Log-File von direktem PS-Output-Read
// 11.10.2021 Simon Beste
// --------------------------------------------------------------

namespace Script {
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Threading.Tasks;
    
    public partial class VuserClass {
        
		private int _timeout = 30;
		private bool _isError;
		
    	private void RunPS(string[] args)
    	{		
    		Process process = new Process();
    		process.StartInfo.FileName = @"powershell.exe";
			process.StartInfo.WorkingDirectory = @"C:\HPBSM\Scripte\Hessen-PKI"; // working dir	
			process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden; //Konsole wird sichbar dargestellt.
			process.StartInfo.UseShellExecute = true; // Muss auf false stehen, um die Ausf�hrung mit R�ckgaben ins vugen umleiten zu k�nnen
			process.StartInfo.RedirectStandardOutput = false; // Umleitung zu vugen
			process.StartInfo.RedirectStandardError = false; // Umleitung zu vugen
			process.StartInfo.CreateNoWindow = false;
			//
			string argsString = "";
			foreach (String arg in args)
			{
				argsString = argsString + arg + " ";
			}
			//
			process.StartInfo.Arguments = @"-ExecutionPolicy Bypass -File C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1 " + argsString;
			lr.output_message(process.StartInfo.FileName + " " + process.StartInfo.Arguments);
			//
            Task<string> processTask = new Task<string>( () =>
            {
				//
				process.Start();
				process.WaitForExit();
				//
				return "";
            });
			//
        	processTask.Start();
			//
        	for (int i = 0; i < _timeout; i++)
			{				
				if (!processTask.IsCompleted)
				{
					lr.output_message("Iteration " + i + " of waiting for script to end.");
					System.Threading.Thread.Sleep(1000);
				}
				else
				{
					lr.output_message("Terminating PS environment");
					return;
				}
			}
			lr.output_message("Could not end PS environment in time!");
        	_isError = true;
        	return;
    	}
    	
    	private bool Matcher(string output, string matchThis)
    	{	
			if (output.Length > 0)
			{

				Match match1 = Regex.Match(Regex.Escape(output),Regex.Escape(matchThis),RegexOptions.IgnoreCase);
				if (match1.Success)
				{
					return true;
				}				
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
    	}
    	
        public int Action()
        {
			string useCase = lr.eval_string("{useCase}");
			string netbiosnameServer = lr.eval_string("{netbiosnameServer}");
			string caName = lr.eval_string("{CAName}");
			string enrollmentURL = lr.eval_string("{EnrollmentURL}");
			string httpURL = lr.eval_string("{httpURL}");
			string ldapURL = lr.eval_string("{ldapURL}");
			string ldapBase = lr.eval_string("{ldapBase}");
			string intervall = lr.eval_string("{Intervall}");
			string p = lr.eval_string("{P}");
               	
	        string[] args = {
	        	useCase,
	        	netbiosnameServer,
	        	caName,
	        	enrollmentURL,
	        	httpURL,
	        	ldapURL,
	        	ldapBase,
	        	intervall,
	        	p
	        };
			
			_isError = false;
			//File.WriteAllText(@"C:\HPBSM\Scripte\Hessen-PKI\" + useCase + ".txt", "");
        	
			lr.start_transaction(useCase);
			RunPS(args);
			//
        	string logContent = System.IO.File.ReadAllText(@"C:\HPBSM\Scripte\Hessen-PKI\" + useCase + ".txt");
        	lr.message(logContent);
			//
			// if standard out contains false, if standard error has any entry, or if there is a timeout when running the powershell script
			if (Matcher(logContent, ":false") || _isError)
       		{
				lr.end_transaction(useCase, lr.FAIL);
       		}
       		else
       		{
				lr.end_transaction(useCase, lr.PASS);       			
       		}
       		//
            return 0;
        }    		
   }
}

