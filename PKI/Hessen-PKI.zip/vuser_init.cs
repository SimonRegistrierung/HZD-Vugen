namespace Script
{
    public partial class VuserClass
    {
        public int vuser_init()
        {
        	if (false)
        	{
				lr.start_transaction("UC1");
				//
				lr.end_transaction("UC1", lr.PASS);
				//
				lr.start_transaction("UC9");
				//
				lr.end_transaction("UC9", lr.PASS);
				//
				lr.start_transaction("UC11");
				//
				lr.end_transaction("UC11", lr.PASS);
				//
				lr.start_transaction("UC12");
				//
				lr.end_transaction("UC12", lr.PASS);
				//
				lr.start_transaction("UC15");
				//
				lr.end_transaction("UC15", lr.PASS);
				//
				lr.start_transaction("UC16");
				//
				lr.end_transaction("UC16", lr.PASS);
				//
				lr.start_transaction("UC17");
				//
				lr.end_transaction("UC17", lr.PASS);
				//
				lr.start_transaction("UC18");
				//
				lr.end_transaction("UC18", lr.PASS);
				//
				lr.start_transaction("UC19");
				//
				lr.end_transaction("UC19", lr.PASS);
				//
				lr.start_transaction("UC20");
				//
				lr.end_transaction("UC20", lr.PASS);
				//
				lr.start_transaction("UC21");
				//
				lr.end_transaction("UC21", lr.PASS);
				//
				lr.start_transaction("UC22");
				//
				lr.end_transaction("UC22", lr.PASS);
				//
				lr.start_transaction("UC23");
				//
				lr.end_transaction("UC23", lr.PASS);
				//
				lr.start_transaction("UC25");
				//
				lr.end_transaction("UC25", lr.PASS);
				//
				lr.start_transaction("UC27");
				//
				lr.end_transaction("UC27", lr.PASS);
				//
				lr.start_transaction("UC29");
				//
				lr.end_transaction("UC29", lr.PASS);
				//
				lr.start_transaction("UC30");
				//
				lr.end_transaction("UC30", lr.PASS);
        	}
        	return 0;
        }
    }
}

