﻿#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1 	UC1	NULL	CA-1-SYSTEMPKI-HESSEN-ROOT-01	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	1600	P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC9	NULL	PCA-1-Verwaltung-17	NULL	x500.bund.de	x500.bund.de	O=PKI-1-Verwaltung[COMMA]C=DE?certificateRevocationList	24	P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC11	SRVITSSPKICA05	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE2-A-02	srvitsspkiep01.itshessen.hessen.de	pki.hessen.de	crl.hessen.de	NULL	NULL	P1P2P3
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC12	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE2-A-02	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC15	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE3-A-02	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC16	NULL	PCA-1-Verwaltung-20	NULL	x500.bund.de	x500.bund.de	O=PKI-1-Verwaltung[COMMA]C=DE?certificateRevocationList	24	P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC17	NULL	CA-1-Hessen07	NULL	pki.hessen.de	x500.bund.de	OU=Land[BLANK]Hessen[COMMA]O=PKI-1-Verwaltung[COMMA]C=DE?certificateRevocationList	24	P4P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC18	NULL	CA-1-SYSTEMPKI-HESSEN-ROOT-02	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	1600	P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC19	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE3-A-03	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC20	SRVITSSPKICA07	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE2-C-01	srvitsspkiep01.itshessen.hessen.de	pki.hessen.de	crl.hessen.de	NULL	NULL	P1P2P3
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC21	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE2-C-01	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC22	SRVITSSPKICA08	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE1-D-01	srvitsspkiep03.itshessen.hessen.de	NULL	NULL	NULL	NULL	P1
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC23	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE1-D-01	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC25	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE2-B-02	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC27	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE2-B-03	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC29	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE2-D-01	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC30	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE3-A-04	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6
###########################


#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1 	UC1	NULL	CA-1-SYSTEMPKI-HESSEN-ROOT-01	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	1600	P5P6
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC11	SRVITSSPKICA05	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE2-A-02	srvitsspkiep01.itshessen.hessen.de	pki.hessen.de	crl.hessen.de	NULL	NULL	P1P2P3
#powershell.exe C:\HPBSM\Scripte\Hessen-PKI\PKI.ps1	UC15	NULL	CA-1-SYSTEMPKI-HESSEN-SUB-KLASSE3-A-03	NULL	pki.hessen.de	crl.hessen.de	OU=System-PKI[COMMA]O=Land[BLANK]Hessen[COMMA]C=DE?certificateRevocationList	200	P4P5P6








