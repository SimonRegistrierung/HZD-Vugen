<#
Description: Script zur ueberwachung von Hessen-PKI
Author: Beste
#>

################ PARAMS ################

param
(
    [parameter(Position = 0)]
    [String]$useCase,
    [parameter(Position = 1)]
    [String]$netbiosnameServer,
    [parameter(Position = 2)]
    [String]$CAName,
    [parameter(Position = 3)]
    [String]$EnrollmentURL,
    [parameter(Position = 4)]
    [String]$httpURL,
    [parameter(Position = 5)]
    [String]$ldapURL,
    [parameter(Position = 6)]
    [String]$ldapBase,
    [parameter(Position = 7)]
    [String]$Intervall,
    [parameter(Position = 8)]
    [String]$P
)

Function RunUseCase
{
    $pResults = [System.Collections.Generic.List[string]]::new()
    $pNames = [System.Collections.Generic.List[string]]::new()
    If ($P.ToUpper() -Match "P6") 
    {
        $tempResult = try{P6}catch{return "P6:false"}
        $pNames.Add("P6") | Out-Null
        $pResults.Add($tempResult) | Out-Null
    }
    If ($P.ToUpper() -Match "P1") 
    {
        $tempResult = try{P1}catch{return "P1:false"}
        $pNames.Add("P1") | Out-Null
        $pResults.Add($tempResult) | Out-Null
    }
    If ($P.ToUpper() -Match "P2") 
    {
        $tempResult = try{P2}catch{return "P2:false"}
        $pNames.Add("P2") | Out-Null
        $pResults.Add($tempResult) | Out-Null
    }
    If ($P.ToUpper() -Match "P3") 
    {
        $tempResult = try{P3}catch{return "P3:false"}
        $pNames.Add("P3") | Out-Null
        $pResults.Add($tempResult) | Out-Null
    }
    If ($P.ToUpper() -Match "P4") 
    {
        $tempResult = try{P4}catch{return "P4:false"}
        $pNames.Add("P4") | Out-Null
        $pResults.Add($tempResult) | Out-Null
    }
    If ($P.ToUpper() -Match "P5") 
    {
        $tempResult = try{P5}catch{return "P4:false"}
        $pNames.Add("P5") | Out-Null
        $pResults.Add($tempResult) | Out-Null
    }
    #
    Write-Host "ARRAY SIZE: $($pResults.Count)"
    for ($i = 0; $i -Lt $pResults.Count; $i++)
    {
        $currentResult = $pResults[$i].ToLower()
        $currentName = $pNames[$i].ToLower()
        Write-Host "================================"
        #Write-Host "$($currentName)"
        Write-Host "$($currentResult)"
        Write-Host "================================"
        Write-Host "$($useCase.ToUpper()) $($currentName.ToUpper()) START" -Fore Magenta
        If ($currentResult.ToLower() -Match "$($currentName):true".ToLower())
        {
            Write-Host $useCase.ToUpper() $currentName.ToUpper() STATUS erfolgreich -Fore Green
        }
        Else
        {
            Write-Host $useCase $currentName STATUS nicht erfolgreich $P1 -Fore Red
        }
        Write-Host "$($useCase.ToUpper()) $($currentName.ToUpper()) ENDE" -Fore Magenta
        Write-Host "================================"
    }
}

################ P DEFINITIONS ################

Function P1
{
    $P1response = certutil -ping -config $netbiosnameServer\$CAName
    Write-Host "certutil -ping -config $netbiosnameServer\$CAName"
    Write-Host "P1response = $P1response"  
    If ($P1response -Like "*success*")
    {
        Write-Host fuehre P1 aus fuer usecase: $useCase
        return "P1:true"
    }
    Else 
    {
        return "$($P1response.Replace("\", "\\"))`nP1:false" # replace regex escape sequences in case of error 
    }
}

Function P2
{
    $P2response = certutil -ping -kerberos -config $EnrollmentURL CEP
    Write-Host "certutil -ping -kerberos -config $EnrollmentURL CEP"
    Write-Host "P2response = $P2response"  
    If ($P2response -Like "*success*")
    {
        Write-Host fuehre P2 aus fuer usecase: $useCase
        return "P2:true"
    }
    Else
    {
        return "$($P2response.Replace("\", "\\"))`nP2:false" # replace regex escape sequences in case of error 
    }
}

Function P3
{
    $P3response = certutil -ping -kerberos -config $EnrollmentURL\$CAName CES
    Write-Host "certutil -ping -kerberos -config $EnrollmentURL\$CAName CES"
    Write-Host "P3response = $P3response"  # Auskommentiert # mit der Ausgabe kommt Vugen nicht klar
    If ($P3response -Like "*success*")
    {
        Write-Host fuehre P3 aus fuer usecase: $useCase
        return "P3:true"
    }
    Else
    {
        return "$($P3response.Replace("\", "\\"))`nP3:false" # replace regex escape sequences in case of error 
    }
}

Function P4
{
    $P4response = cmd.exe /c "C:\HPBSM\Scripte\Hessen-PKI\openSSL\openssl.exe ocsp -issuer C:\HPBSM\Scripte\Hessen-PKI\Cert\$CAName.base64.cer -cert C:\HPBSM\Scripte\Hessen-PKI\Cert\endentity_$CAName.base64.cer -url http://ocsp.hessen.de/ocsp -no_cert_verify -no_nonce" 2>&1 | %{ "$_" }
    Write-Host "C:\HPBSM\Scripte\Hessen-PKI\openSSL\openssl.exe ocsp -issuer C:\HPBSM\Scripte\Hessen-PKI\Cert\$CAName.base64.cer -cert C:\HPBSM\Scripte\Hessen-PKI\Cert\endentity_$CAName.base64.cer -url http://ocsp.hessen.de/ocsp -no_cert_verify -no_nonce"
    Write-Host "P4Response: $P4response"
   
    $found = $P4response -match "(Next Update)"
    $found = $found.Substring(13)
    
    $foundM = $found.split(' ')[1]  #month
    $foundD = $found.split(' ')[2]  #day
    $foundT = $found.split(' ')[3]  #time
    $foundY = $found.split(' ')[4]  #year

    #bei den Tagen 1-9 gibt es ein Leerzeichen mehr deshalb shIft um ein feld
    If ($foundT.length -eq 1)
    {
  
        $foundD = $found.split(' ')[3]  #day
        $foundT = $found.split(' ')[4]  #time
        $foundY = $found.split(' ')[5]  #year
    }

    $found = "$foundM $foundD $foundY $foundT"
    Write-Host $P4response
    Write-Host found: $found 

    $dt = (Get-Item ".").LastWriteTime #Aktuelle lokal Zeit
    $dts = $dt.ToString("dd.MM.yyyy HH:mm")

    $jahreswechsel = ((Get-Date "$found").Year - (Get-Date "$dts").Year)*365
    $calculateDates = ((((Get-Date "$found").DayOfYear+$jahreswechsel) - (Get-Date "$dts").DayOfYear)*24) + (((Get-Date "$found").Hour - (Get-Date "$dts").Hour)) + (((Get-Date "$found").Minute - (Get-Date "$dts").Minute))/60
    Write-Host wenn $calculateDates groesser gleich "48" dann pass -ForegroundColor Yellow #("dd.MM.yyyy HH:mm")

    If ($calculateDates -ge 48) 
    {
        Write-Host fuehre P4 aus fuer usecase: $useCase
        return "P4:true"
    }
    Else 
    {
        return "$($P4response.Replace("\", "\\"))`nP4:false" # replace regex escape sequences in case of error 
    }

}

Function P5
{
    #"UseCases" Zeile 25 festgelegte Intervall gueltig sein. 
    Write-Host "certutil -dump $global:foundSperrliste.crl"
    $P5response = certutil -dump "$global:foundSperrliste.crl"
    
    #Nächste Aktualisierung: 03.02.2019 09:40
    $found = $P5response -match "(NextUpdate: \d{2}.\d{2}.\d{4} \d{2}:\d{2})" #*chste Aktualisierung
    # echo $found >> erstesfound.txt
    #$found = $found -match "([0-9]+)"
    $foundYear = $found.Substring(11) #Schneidet "Nächste Aktualisierung String ab"
    $foundYear = $foundYear = $foundYear.substring($foundYear.length - 16, 16) # Nimmt die hinteren 16 Stellen
    Write-Host $foundYear -ForegroundColor Cyan
    #   Write-Host XXXYYYY (Get-Date "$foundYear").DayOfYear -ForegroundColor Magenta
    #$STARTDATE = " 5/27/2019"#$foundYear    # specIfic non-default date format
    #$foundYear# = $STARTDATE 

    $dt = (Get-Item ".").LastWriteTime #Aktuelle lokal Zeit
    $dts = $dt.ToString("dd.MM.yyyy HH:mm")
    #$dts = $dt
    #  $dts = $Lastfound

    #   Write-Host $dts -ForegroundColor DarkGray
    #dts = this; foundYear = next;

    $jahreswechsel = ((Get-Date "$foundYear").Year - (Get-Date "$dts").Year)*365

    $calculateDates = ( ((((Get-Date "$foundYear").DayOfYear)+$jahreswechsel)*24) - (((Get-Date "$dts").DayOfYear)*24)  + (((Get-Date "$foundYear").Hour - (Get-Date "$dts").Hour)) + (((Get-Date "$foundYear").Minute - (Get-Date "$dts").Minute))/60 )
    #echo $calculateDates >> firstDate.txt     
    If ($calculateDates -lt "0")
    {
        $calculateDates = $calculateDates*(-1)
    }
    Write-Host wenn $calculateDates groesser gleich $Intervall dann pass -ForegroundColor Yellow #("dd.MM.yyyy HH:mm")
    If ($calculateDates -ge $Intervall)
    {
        Write-Host true -BackgroundColor DarkBlue -ForegroundColor Yellow}Else {Write-Host False -BackgroundColor DarkRed -ForegroundColor White
    } #-ge  größer oder gleich  

    If ($P5response -Like "*success*")
    {
        rm "$global:foundSperrliste.crl"
        Write-Host "rm $global:foundSperrliste.crl"
        Write-Host fuehre P5 aus fuer usecase: $useCase
        return "P5:true"
    }
    Else
    {
        rm "$global:foundSperrliste.crl"
        Write-Host "rm $global:foundSperrliste.crl"
        return "$($P4response.Replace("\", "\\"))`nP4:false" # replace regex escape sequences in case of error 
    }
}

Function P6
{
    #Sperrlistenhash(sha1): c0130e027a60768c6ba23bf57b80f45a4f16cd0b CertUtil:
    Write-Host "certutil -store -split ldap://$ldapURL/CN = $CAName,$ldapBase"
    $ldapbefehl = "ldap://$ldapURL/CN = $CAName,$ldapBase"
    Write-Host "certutil"$ldapbefehl -ForegroundColor Yellow
    $P6response = certutil -store -split $ldapbefehl # certutil -store -split ldap://$ldapURL/CN = $CAName,$ldapBase
    
    Write-Host "P6response = $P6response"  
    If ($P6response -like "*success*")
    {
        [string]$P6response -match "(?<=CRL Hash\(sha1\): )\w+" | Out-Null
        $global:foundSperrliste = $matches[0]
        Write-Host $global:foundSperrliste -ForegroundColor Yellow
        Write-Host fuehre P6 aus fuer usecase: $useCase
        return "P6:true"
    }
    Else
    {
        return "$($P6response.Replace("\", "\\"))`nP4:false" # replace regex escape sequences in case of error 
    }
}

################ RUN LOGIC ################

$ldapBase = $ldapBase.Replace("[BLANK]"," ")
$ldapBase = $ldapBase.Replace("[COMMA]",",")

$global:foundSperrliste = $null

Start-Transcript -Path "C:\HPBSM\Scripte\Hessen-PKI\$useCase.txt"
RunUseCase
Stop-Transcript
