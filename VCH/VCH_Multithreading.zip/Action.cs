// ---------------------------------------------
// 	VCH Multithreading Test Script
// 	Dr. Simon Beste 
//	16.10.2023
//	HZD
// ---------------------------------------------

namespace Script 
{
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    using System.Globalization;
    using System.Diagnostics;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    using System.Threading;
    using System.IO;
    using System.Collections;
    using System.Timers;
    using System.Text;
        
    public class Powershell
    {
    	private string scriptDir;
		private string scriptName;
		private string scriptFullPath;
		private string instanceName;
		
		private string logFile;
    	private string archive1;
    	private string archive2;
		
		public Process PSProcess;
		public int LineCount = 0;
    	public StringBuilder Output = new StringBuilder();
    	
		public Powershell(string instanceName, string scriptDir, string scriptName, string scriptFullPath)
		{
			this.instanceName = instanceName;
			this.scriptDir = scriptDir;
			this.scriptName = scriptName;
			this.scriptFullPath = scriptFullPath;
			
			logFile = scriptDir + instanceName + ".log";
			archive1 = scriptDir + instanceName + ".archive1";
			archive2 = scriptDir + instanceName + ".archive2";
		}
		
    	public void Start()
    	{
    		ProcessStartInfo startInfo = new ProcessStartInfo
			{
				FileName = "powershell.exe",
				WorkingDirectory = scriptDir,
				Arguments = "-ExecutionPolicy ByPass -NoProfile -NonInteractive -File "  + scriptFullPath + " -clustername " + instanceName + " -dir " + scriptDir,
				UseShellExecute = false,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				CreateNoWindow = true
			};
			
    		PSProcess = new Process();
    		PSProcess.StartInfo = startInfo;
			PSProcess.OutputDataReceived += new DataReceivedEventHandler((sender, e) =>
	        {
	            // Prepend line numbers to each line of the output.
	            if (!String.IsNullOrEmpty(e.Data))
	            {
	                LineCount++;
	                Output.Append("\n[" + LineCount + "]: " + e.Data);
	            }
	        });
			//
			PSProcess.ErrorDataReceived += new DataReceivedEventHandler((sender, e) =>
	        {
	            // Prepend line numbers to each line of the output.
	            if (!String.IsNullOrEmpty(e.Data))
	            {
	                LineCount++;
	                Output.Append("\n[" + LineCount + "]: " + e.Data);
	            }
	        });
    		//
			PSProcess.Start();
			PSProcess.BeginOutputReadLine();
			PSProcess.BeginErrorReadLine();
			PSProcess.WaitForExit();
    	}
    	
    	public void WriteResults(string output)
    	{        	
        	if (System.IO.File.Exists(logFile))
            {
            	System.IO.File.Delete(logFile);
            }
        	
        	System.IO.File.WriteAllText(logFile, output);			
			System.IO.File.AppendAllText(archive1, "---------  " + DateTime.Now + "  ---------\n" + output + "----------------------------------------\n\n");
			
			if (new FileInfo(archive1).Length > 20000000)
			{
				System.IO.File.Delete(archive2); // delete very old logs
				System.IO.File.Copy(archive1, archive2); // copy contents of archive 1 to 2
				System.IO.File.WriteAllText(archive1, ""); // empty archive 1
			}
    	}
    }
   
    public partial class VuserClass 
    {   
    	private ArrayList powershells = new ArrayList();
		private ArrayList threads = new ArrayList();
		
		private static string scriptDir = @"C:\HPBSM\Scripte\VCH\";
		private static string scriptName = @"Service_Availability_5.0.ps1";
		private static string scriptFullPath = scriptDir + scriptName;
		
    	private int counter = 0;
    	
    	private string[] clusterNames = {
			"CLUVCHESXMAOAMMZ01",
			"CLUVCHESXMAOAMWI01",
			"CLUVCHESXEJUSTICEMZ01",
			"CLUVCHESXEJUSTICEMZ02",
			"CLUVCHESXEJUSTICEWI01",
			"CLUVCHESXEJUSTICEWI02",
			"CLUVCHESXSHPMZ01",
			"CLUVCHESXSHPMZ02",
			"CLUVCHESXSHPWI01",
			"CLUVCHESXPOLWI01",
			"CLUVCHESXPOLWI02",
			"CLUVCHESXHSLMZ01",
			"CLUVCHESXMAOAMHD01",
			"CLUVCHESXJUSTIZTSTHD01",
			"CLUVCHESXJUSTIZHD01",
			"CLUVCHESXJUSTIZHD02"
    	};  	
    	
        public int Action()
        {
        	// START THREADS ASYNCHRONOUSLY
        	foreach (string clusterName in clusterNames)
        	{
        		// TRANSACTION
        		lr.start_transaction(clusterName + "@@ALL");
        		lr.start_transaction(clusterName + "@@CONNECT");
        		
        		// POWERSHELL OBJECT
        		Powershell ps = new Powershell(clusterName, scriptDir, scriptName, scriptFullPath);
        		powershells.Add(ps);
        		
        		lr.log_message(DateTime.Now + " - Starting Powershell Thread for " + clusterNames[counter]);
        		
        		// MULTI-THREADING
        		Thread thread = new Thread(() => ps.Start());
      			thread.Start();
				threads.Add(thread);
				System.Threading.Thread.Sleep(250); // some time for the machine before starting the next thread
        		counter++;
    		}
        	
        	// CHECK UP ON EACH INDIVIDUAL THREAD AFTER STARTING IT
        	counter = 0;
        	foreach (Thread thread in threads)
        	{
        		// RETRIEVE THE POWERSHELL SESSION
        		Powershell ps = (Powershell)powershells[counter]; 
        		for (int iteration = 0; true; iteration++)
        		{
        			// CHECK FOR THE STATE OF THE PS SESSION AND THE ATTACHED PROCESSES
        			if (thread.ThreadState.ToString().Equals("Stopped") && ps.PSProcess.HasExited)
	        		{
        				string message = "=== " + DateTime.Now + " - DONE: " + clusterNames[counter] + " ===";
	        			lr.log_message(message);
	        			ps.WriteResults(message + "\n" + ps.Output.ToString());
	        			//
	        			// CHECK UP ON THE SUCCESS OF THE OPERATION AFTER THE PROCESS HAS TERMINATED
	        			bool foundPass = Matcher(ps.Output.ToString(), clusterNames[counter] + ":0");
	        			bool foundFail = Matcher(ps.Output.ToString(), clusterNames[counter] + ":-2");
						//	        			
						if (foundPass)
			        	{
			        		lr.end_transaction(clusterNames[counter] + "@@CONNECT", lr.PASS);  
							lr.end_transaction(clusterNames[counter] + "@@ALL", lr.PASS);  
			        	}
			        	else 
			        	{
			        		lr.end_transaction(clusterNames[counter] + "@@CONNECT", lr.FAIL);
							lr.end_transaction(clusterNames[counter] + "@@ALL", lr.FAIL);
			        	}
			        	//
	        			break;
	        		}
	        		else
	        		{
	        			lr.log_message("ITERATION: " + iteration);
	        			lr.log_message("- " + clusterNames[counter] + " thread state: " + thread.ThreadState.ToString());
	        			if (iteration < 20) // NUMBER OF SECONDS TO WAIT
		        		{
		        			lr.log_message("=== " + DateTime.Now + " - WAITING: " + clusterNames[counter] + " ===");
		        			System.Threading.Thread.Sleep(1000);
		        			continue;
		        		}
		        		else
		        		{
		        			string message = "=== " + DateTime.Now + " - TIMED OUT: " + clusterNames[counter] + " ===";
		        			lr.log_message(message);
		        			ps.WriteResults(message + "\n" + ps.Output.ToString());
		        			ps.PSProcess.Kill();
		        			ps.PSProcess.Dispose();
		        			thread.Abort();
		        			lr.end_transaction(clusterNames[counter] + "@@ALL", lr.FAIL);
	        				lr.end_transaction(clusterNames[counter] + "@@CONNECT", lr.FAIL);
		        			break;
		        		}
	        		}	        		
        		}
        		lr.log_message(DateTime.Now + " - Powershell Thread for " + clusterNames[counter] + " has terminated.");
        		counter++;
        	}
			return 0;
		}
        
        private bool Matcher(string output, string matchThis)
    	{	
			if (output.Length > 0)
			{

				Match match1 = Regex.Match(Regex.Escape(output),Regex.Escape(matchThis),RegexOptions.IgnoreCase);
				if (match1.Success)
				{
					return true;
				}				
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
    	}
	}
}