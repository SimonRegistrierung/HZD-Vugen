namespace Script
{
    public partial class VuserClass
    {
        public int vuser_init()
        {
        	 if (false)
        	 {
				lr.start_transaction("CLUVCHESXMAOAMMZ01@@CONNECT");
	 			lr.start_transaction("CLUVCHESXMAOAMWI01@@CONNECT");
	 			lr.start_transaction("CLUVCHESXMAOAMHD01@@CONNECT");
	 			lr.start_transaction("CLUVCHESXEJUSTICEMZ01@@CONNECT");
				lr.start_transaction("CLUVCHESXEJUSTICEMZ02@@CONNECT");
				lr.start_transaction("CLUVCHESXEJUSTICEWI01@@CONNECT");
				lr.start_transaction("CLUVCHESXEJUSTICEWI02@@CONNECT");
				lr.start_transaction("CLUVCHESXJUSTIZTSTHD01@@CONNECT");
				lr.start_transaction("CLUVCHESXJUSTIZHD01@@CONNECT");
				lr.start_transaction("CLUVCHESXJUSTIZHD02@@CONNECT");
				lr.start_transaction("CLUVCHESXSHPMZ01@@CONNECT");
				lr.start_transaction("CLUVCHESXSHPMZ02@@CONNECT");
				lr.start_transaction("CLUVCHESXSHPWI01@@CONNECT");
				lr.start_transaction("CLUVCHESXPOLWI01@@CONNECT");
				lr.start_transaction("CLUVCHESXPOLWI02@@CONNECT");
				lr.start_transaction("CLUVCHESXHSLMZ01@@CONNECT");

				
				lr.start_transaction("CLUVCHESXMAOAMMZ01@@ALL");
	 			lr.start_transaction("CLUVCHESXMAOAMWI01@@ALL");
	 			lr.start_transaction("CLUVCHESXMAOAMHD01@@ALL");
	 			lr.start_transaction("CLUVCHESXEJUSTICEMZ01@@ALL");
				lr.start_transaction("CLUVCHESXEJUSTICEMZ02@@ALL");
				lr.start_transaction("CLUVCHESXEJUSTICEWI01@@ALL");
				lr.start_transaction("CLUVCHESXEJUSTICEWI02@@ALL");
				lr.start_transaction("CLUVCHESXJUSTIZTSTHD01@@ALL");
				lr.start_transaction("CLUVCHESXJUSTIZHD01@@ALL");
				lr.start_transaction("CLUVCHESXJUSTIZHD02@@ALL");
				lr.start_transaction("CLUVCHESXSHPMZ01@@ALL");
				lr.start_transaction("CLUVCHESXSHPMZ02@@ALL");
				lr.start_transaction("CLUVCHESXSHPWI01@@ALL");
				lr.start_transaction("CLUVCHESXPOLWI01@@ALL");
				lr.start_transaction("CLUVCHESXPOLWI02@@ALL");
				lr.start_transaction("CLUVCHESXHSLMZ01@@ALL");
				
				
				lr.end_transaction("CLUVCHESXMAOAMMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMWI01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMHD01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEMZ02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZTSTHD01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPWI01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXHSLMZ01@@CONNECT", lr.PASS);
				
				
				lr.end_transaction("CLUVCHESXMAOAMMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMWI01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMHD01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEMZ02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZTSTHD01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPWI01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXHSLMZ01@@ALL", lr.PASS);
     		}
        	return 0;
        }
    }
}

