using System;
using System.IO;
using System.Security.Cryptography;

namespace Script
{
	internal static class Cryptor
	{
	    private static Rijndael alg = Rijndael.Create();
	    private static byte[] key = new byte[32] { 118, 123, 23, 17, 161, 152, 35, 68, 126, 213, 16, 115, 68, 217, 58, 108, 56, 218, 5, 78, 28, 128, 113, 208, 61, 56, 10, 87, 187, 162, 233, 38 };
	    private static byte[] iv = new byte[16] { 33, 241, 14, 16, 103, 18, 14, 248, 4, 54, 18, 5, 60, 76, 16, 191};
	    //
		internal static string EncryptStringAsBytesToBase64String(string plainText)
	    {
	        if (plainText == null || plainText.Length <= 0)
	        {            
	            throw new ArgumentNullException("plainText");
	        }
	        if (key == null || key.Length <= 0)
	        {            	
	            throw new ArgumentNullException("Key");
	        }
	        if (iv == null || iv.Length <= 0)
	        {            	
	            throw new ArgumentNullException("IV");
	        }
	        //
	        byte[] encrypted;
	        //
	        using (Rijndael alg = Rijndael.Create())
	        {
	            alg.Key = key;
	            alg.IV = iv;
	            //
	            ICryptoTransform encryptor = alg.CreateEncryptor(alg.Key, alg.IV);
	            //
	            using (MemoryStream msEncrypt = new MemoryStream())
	            {
	                using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
	                {
	                    using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
	                    {
	                        swEncrypt.Write(plainText);
	                    }
	                    encrypted = msEncrypt.ToArray();
	                }
	            }
	        }
	        return Convert.ToBase64String(encrypted, 0, encrypted.Length, Base64FormattingOptions.InsertLineBreaks);
	    }
	
	    internal static string DecryptStringFromBytesToBase64String(string cipherTextBase64)
	    {
	    	byte[] cipherText = Convert.FromBase64String(cipherTextBase64);        		
	        if (cipherText == null || cipherText.Length <= 0)
	        {
	            throw new ArgumentNullException("cipherText");            	
	        }
	        if (key == null || key.Length <= 0)
	        {            	
	            throw new ArgumentNullException("Key");
	        }
	        if (iv == null || iv.Length <= 0)
	        {            	
	            throw new ArgumentNullException("IV");
	        }
			//
	        string plaintext = null;
			//
	        using (Rijndael alg = Rijndael.Create())
	        {
	            alg.Key = key;
	            alg.IV = iv;
				//
	            ICryptoTransform decryptor = alg.CreateDecryptor(alg.Key, alg.IV);
				//
	            using (MemoryStream msDecrypt = new MemoryStream(cipherText))
	            {
	                using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
	                {
	                    using (StreamReader srDecrypt = new StreamReader(csDecrypt))
	                    {
	                        plaintext = srDecrypt.ReadToEnd();
	                    }
	                }
	            }
	        }
	        return plaintext;
	    }
	}
}
