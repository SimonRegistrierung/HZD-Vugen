namespace Script
{
    public partial class VuserClass
    {
        public int vuser_init()
        {
        	 if (false)
        	 {
        	 	
        	 	//lr.start_transaction("CLUVCHESXMAOAMMZ01@@ALL");
				lr.start_transaction("CLUVCHESXMAOAMMZ02@@ALL");
	 			//lr.start_transaction("CLUVCHESXMAOAMWI01@@ALL");
	 			lr.start_transaction("CLUVCHESXMAOAMWI02@@ALL");
	 			lr.start_transaction("CLUVCHESXMAOAMHD01@@ALL");
				lr.start_transaction("CLUVCHESXSHPMZ01@@ALL");
				lr.start_transaction("CLUVCHESXSHPMZ02@@ALL");
				lr.start_transaction("CLUVCHESXSHPMZ03@@ALL");
				lr.start_transaction("CLUVCHESXSHPMZ04@@ALL");
				lr.start_transaction("CLUVCHESXEXTDMZMZ01@@ALL");
				lr.start_transaction("CLUVCHESXSHPWI01@@ALL");
			//	lr.start_transaction("CLUVCHESXPOLWI01@@ALL");
			//	lr.start_transaction("CLUVCHESXPOLWI02@@ALL");
				lr.start_transaction("CLUVCHESXHSLMZ01@@ALL");
				lr.start_transaction("CLUVCHESXVDIMZ01@@ALL");
				lr.start_transaction("CLUVCHESXVDIMZ02@@ALL");
				//lr.start_transaction("CLUVCHESXWTSMZ01@@ALL");
				lr.start_transaction("CLUVCHESXWTSMZ02@@ALL");
				lr.start_transaction("CLUVCHESXPOLWI03@@ALL");
				lr.start_transaction("CLUVCHESXPOLWI04@@ALL");
				
			//	lr.start_transaction("CLUVCHESXMAOAMMZ01@@CONNECT");
				lr.start_transaction("CLUVCHESXMAOAMMZ02@@CONNECT");
	 			//lr.start_transaction("CLUVCHESXMAOAMWI01@@CONNECT");
	 			lr.start_transaction("CLUVCHESXMAOAMWI02@@CONNECT");
	 			lr.start_transaction("CLUVCHESXMAOAMHD01@@CONNECT");
				lr.start_transaction("CLUVCHESXSHPMZ01@@CONNECT");
				lr.start_transaction("CLUVCHESXSHPMZ02@@CONNECT");
				lr.start_transaction("CLUVCHESXSHPMZ03@@CONNECT");
				lr.start_transaction("CLUVCHESXSHPMZ04@@CONNECT");
				lr.start_transaction("CLUVCHESXEXTDMZMZ01@@CONNECT");
				lr.start_transaction("CLUVCHESXSHPWI01@@CONNECT");
				//lr.start_transaction("CLUVCHESXPOLWI01@@CONNECT");
				//lr.start_transaction("CLUVCHESXPOLWI02@@CONNECT");
				lr.start_transaction("CLUVCHESXHSLMZ01@@CONNECT");
				lr.start_transaction("CLUVCHESXVDIMZ01@@CONNECT");
				lr.start_transaction("CLUVCHESXVDIMZ02@@CONNECT");
				//lr.start_transaction("CLUVCHESXWTSMZ01@@CONNECT");
				lr.start_transaction("CLUVCHESXWTSMZ02@@CONNECT");
				lr.start_transaction("CLUVCHESXPOLWI03@@CONNECT");
				lr.start_transaction("CLUVCHESXPOLWI04@@CONNECT");

								
			//	lr.end_transaction("CLUVCHESXMAOAMMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMMZ02@@CONNECT", lr.PASS);
				//lr.end_transaction("CLUVCHESXMAOAMWI01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMWI02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMHD01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ03@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ04@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEXTDMZMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPWI01@@CONNECT", lr.PASS);
				//lr.end_transaction("CLUVCHESXPOLWI01@@CONNECT", lr.PASS);
				//lr.end_transaction("CLUVCHESXPOLWI02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXHSLMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXVDIMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXVDIMZ02@@CONNECT", lr.PASS);
				//lr.end_transaction("CLUVCHESXWTSMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXWTSMZ02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI03@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI04@@CONNECT", lr.PASS);
				
				
			//	lr.end_transaction("CLUVCHESXMAOAMMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMMZ02@@ALL", lr.PASS);
				//lr.end_transaction("CLUVCHESXMAOAMWI01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMWI02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXMAOAMHD01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ03@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPMZ04@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEXTDMZMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPWI01@@ALL", lr.PASS);
				//lr.end_transaction("CLUVCHESXPOLWI01@@ALL", lr.PASS);
				//lr.end_transaction("CLUVCHESXPOLWI02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXHSLMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXVDIMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXVDIMZ02@@ALL", lr.PASS);
				//lr.end_transaction("CLUVCHESXWTSMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXWTSMZ02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI03@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI04@@ALL", lr.PASS);
				
				
     		}
        	return 0;
        }
    }
}

