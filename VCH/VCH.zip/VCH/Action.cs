// ---------------------------------------------
// 	VCH
// 	Dr. Simon Beste 
//	03.04.2023
//	HZD
// ---------------------------------------------

namespace Script 
{
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    using System.Diagnostics;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    using System.IO;
        
    public partial class VuserClass 
    {
    	private String StartProcess(string scriptName, string clusterName)
    	{
    		var startInfo = new ProcessStartInfo
			{
				FileName = "powershell.exe",
				WorkingDirectory = @"C:\HPBSM\Scripte\VCH\",
				Arguments = "-ExecutionPolicy Bypass "  + scriptName + " -clustername " + clusterName,
				UseShellExecute = false,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				CreateNoWindow = true,
				UserName = "svcvchinsmprbusr",
				Domain = "MAOAM",
				PasswordInClearText = Cryptor.DecryptStringFromBytesToBase64String("82uZM9FRuyXXQ2y+AdFUa3tKyy8gp8/g/i2QHBmQdNY=")
			};
    		
        	lr.output_message("Powershell Input:");
        	lr.output_message("-----------------");
        	lr.output_message(startInfo.FileName + " " + startInfo.Arguments);
        	lr.output_message("-----------------");
			
			// lr.output_message("Starting PS environment for " + clusterName);
			
			// run in background
            // Task processTask = Task.Run(() =>
            Task<string> processTask = new Task<string>( () =>
            {
            	string logFile = startInfo.WorkingDirectory + clusterName + ".logVugen";
            	string archive1 = startInfo.WorkingDirectory + clusterName + ".logVugen.archive1";
            	string archive2 = startInfo.WorkingDirectory + clusterName + ".logVugen.archive2";
            	
            	if (System.IO.File.Exists(logFile))
                {
                	System.IO.File.Delete(logFile);
                }
            	
                Process process = Process.Start(startInfo);
                StreamReader readerOut = process.StandardOutput;
                StreamReader readerErr = process.StandardError;
				string output = readerOut.ReadToEnd();
				output += "\n" + readerErr.ReadToEnd();
				
				System.IO.File.WriteAllText(logFile, output);
				
				System.IO.File.AppendAllText(archive1, "---------  " + DateTime.Now + "  ---------\n" + output + "----------------------------------------\n\n");
				
				if (new FileInfo(archive1).Length > 20000000)
				{
					System.IO.File.Delete(archive2); // delete very old logs
					System.IO.File.Copy(archive1, archive2); // copy contents of archive 1 to 2
					System.IO.File.WriteAllText(archive1, ""); // empty archive 1
				}
				
				return output;
            });
            
            processTask.Start();
			
			for (int i = 0; i < 45; i++)
			{
				if (!processTask.IsCompleted)
				{
					lr.output_message("Iteration " + i + " of waiting for script to end.");
					System.Threading.Thread.Sleep(1000);
				}
				else
				{
					lr.output_message("Terminating PS environment for " + clusterName);
					return processTask.Result;
				}
			}
			
			lr.error_message("Could not end environment for " + clusterName + " in time!");
			return "";			
    	}
    	
    	private bool Matcher(string output, string matchThis)
    	{	
			if (output.Length > 0)
			{

				Match match1 = Regex.Match(Regex.Escape(output),Regex.Escape(matchThis),RegexOptions.IgnoreCase);
				if (match1.Success)
				{
					return true;
				}				
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
    	}
    	
        public int Action()
        {
        	string clusterName = lr.eval_string("{Clustername}");
        	        	
        	///
        	
        	// Starten von Transaktionen  
			lr.start_transaction(clusterName + "@@ALL");        	
			lr.start_transaction(clusterName + "@@CONNECT");
        

        	string scriptPath = @"C:\HPBSM\Scripte\VCH\Service_Availability.ps1";
        	
        	string output = StartProcess(scriptPath, clusterName);
//        	string output = Cryptor.DecryptStringFromBytesToBase64String("82uZM9FRuyXXQ2y+AdFUa3tKyy8gp8/g/i2QHBmQdNY=");
//        	lr.output_message(output);
        	
        	lr.output_message("Powershell Output:");
        	lr.output_message("-----------------");
        	lr.output_message(output);
        	lr.output_message("-----------------");
        	
        	bool FoundString0 = Matcher(output, clusterName+":0");     
			bool FoundString1 = Matcher(output, clusterName+":-2");          	
        	
		if (FoundString1)
        	{
        		lr.error_message(output);
        		lr.end_transaction(clusterName + "@@CONNECT", lr.PASS);  
        	}
        	else if (!FoundString1 && !FoundString0) 
        	{
        		lr.error_message(output);
        		lr.end_transaction(clusterName + "@@CONNECT", lr.FAIL);  
        	}
        	
        	
			if (FoundString0)
        	{
				lr.end_transaction(clusterName + "@@ALL", lr.PASS); 
        		lr.end_transaction(clusterName + "@@CONNECT", lr.PASS);  
				 
        	}
        	else 
        	{
				lr.end_transaction(clusterName + "@@ALL", lr.FAIL);
        	}
        	

        	
        	///
        	///
        	        	
			return 0;
		}
	}
}