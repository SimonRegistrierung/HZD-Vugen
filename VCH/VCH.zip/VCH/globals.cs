namespace Script 
{
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
        
    public partial class VuserClass {
    }
}
