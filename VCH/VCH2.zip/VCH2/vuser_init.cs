namespace Script
{
    public partial class VuserClass
    {
        public int vuser_init()
        {
        	 if (false)
        	 {
        	 	
        	 		//lr.start_transaction("CLUVCHESXEJUSTICEMZ01@@ALL");
				lr.start_transaction("CLUVCHESXEJUSTICEMZ02@@ALL");
				lr.start_transaction("CLUVCHESXEJUSTICEMZ03@@ALL");
				//lr.start_transaction("CLUVCHESXEJUSTICEWI01@@ALL");
				lr.start_transaction("CLUVCHESXEJUSTICEWI02@@ALL");
				lr.start_transaction("CLUVCHESXEJUSTICEWI03@@ALL");
				lr.start_transaction("CLUVCHESXEJUSTICEWI04@@ALL");
				lr.start_transaction("CLUVCHESXJUSTIZTSTHD01@@ALL");
				lr.start_transaction("CLUVCHESXJUSTIZHD01@@ALL");
				lr.start_transaction("CLUVCHESXJUSTIZHD02@@ALL");
				lr.start_transaction("CLUVCHESXJUSTIZHD03@@ALL");
				lr.start_transaction("CLUVCHESXJUSTIZHD04@@ALL");
				lr.start_transaction("CLUVCHESXPOLWI03@@ALL");
				lr.start_transaction("CLUVCHESXPOLWI04@@ALL");
				lr.start_transaction("CLUVCHESXEXTDMZWI01@@ALL");
				lr.start_transaction("CLUVCHESXSHPHD01@@ALL");
				
	 			//lr.start_transaction("CLUVCHESXEJUSTICEMZ01@@CONNECT");
				lr.start_transaction("CLUVCHESXEJUSTICEMZ02@@CONNECT");
				lr.start_transaction("CLUVCHESXEJUSTICEMZ03@@CONNECT");
				//lr.start_transaction("CLUVCHESXEJUSTICEWI01@@CONNECT");
				lr.start_transaction("CLUVCHESXEJUSTICEWI02@@CONNECT");
				lr.start_transaction("CLUVCHESXEJUSTICEWI03@@CONNECT");
				lr.start_transaction("CLUVCHESXEJUSTICEWI04@@CONNECT");
				lr.start_transaction("CLUVCHESXJUSTIZTSTHD01@@CONNECT");
				lr.start_transaction("CLUVCHESXJUSTIZHD01@@CONNECT");
				lr.start_transaction("CLUVCHESXJUSTIZHD02@@CONNECT");
				lr.start_transaction("CLUVCHESXJUSTIZHD03@@CONNECT");
				lr.start_transaction("CLUVCHESXJUSTIZHD04@@CONNECT");
				lr.start_transaction("CLUVCHESXPOLWI03@@CONNECT");
				lr.start_transaction("CLUVCHESXPOLWI04@@CONNECT");
				lr.start_transaction("CLUVCHESXEXTDMZWI01@@CONNECT");
				lr.start_transaction("CLUVCHESXSHPHD01@@CONNECT");
				

					
				//lr.end_transaction("CLUVCHESXEJUSTICEMZ01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEMZ02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEMZ03@@CONNECT", lr.PASS);
				//lr.end_transaction("CLUVCHESXEJUSTICEWI01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI03@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI04@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZTSTHD01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD02@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD03@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD04@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI03@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI04@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXEXTDMZWI01@@CONNECT", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPHD01@@CONNECT", lr.PASS);
				
				//lr.end_transaction("CLUVCHESXEJUSTICEMZ01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEMZ02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEMZ03@@ALL", lr.PASS);
				//lr.end_transaction("CLUVCHESXEJUSTICEWI01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI03@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEJUSTICEWI04@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZTSTHD01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD02@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD03@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXJUSTIZHD04@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI03@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXPOLWI04@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXEXTDMZWI01@@ALL", lr.PASS);
				lr.end_transaction("CLUVCHESXSHPHD01@@ALL", lr.PASS);
				
				
     		}
        	return 0;
        }
    }
}

