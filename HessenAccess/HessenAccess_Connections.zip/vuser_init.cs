//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 
//---------------------------------------------

namespace Script
{
    public partial class VuserClass
    {
        public int vuser_init()
        {		
            return 0;
        }
    }
}

