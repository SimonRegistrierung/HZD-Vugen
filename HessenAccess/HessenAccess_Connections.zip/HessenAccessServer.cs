using System;

namespace Script
{
	public class HessenAccessServer
	{
		public string Name;
		public string ConnectionsStr;
		public int Connections;
		public string Timestamp;
		
		public HessenAccessServer(string name, string connections, string timestamp)
		{
			Name = name;
			ConnectionsStr = connections;
			Connections = Int32.Parse(connections);
			Timestamp = timestamp;
		}
	}
}
