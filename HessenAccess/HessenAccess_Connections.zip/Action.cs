//---------------------------------------------
//Script Title        : HessenAccess_Connections
//Script Description  : Die per SCOM erhobenen Routen auf den HessenAccess-RAS-Servern werden auf der SCOM-Datenbank mit MSSQL-Query abgefragt
//						Die Routen aller Server, die einen Routenwert > 0 zur�ckgeben, werden addiert und bilden den aktuellen Wert.
//						Dieser Wert wird mit den Wert des vorigen Messamples verglichen. 
//						Anschlie�end wird das Ergebnis mittels verschiedener Messszenarien (scenarios) eingeordnet und entschieden, 
//						ob eine gr�ne oder rote Signalisierung erfolgt.
//
//						Detaillierte Informationen finden sich in der offiziellen Dokumentation.
//						
//						HZD, 2025, Dr. Simon Beste
//
//---------------------------------------------

using System.Data.SqlClient;
using System.Collections.Generic;
using System;
using System.Text;
using System.IO;

namespace Script
{
    public partial class VuserClass
    {
    	private static List<HessenAccessServer> _servers = new List<HessenAccessServer>();
    	private static int newVal;
    	    	
    	private static string dir = @"C:\HPBSM\Scripte\HessenAccess\";
    	
    	private static int lastKnownStatus;
    	private static string lastKnownStatusFile = dir + "last_known_status.txt";
    	
    	private static string valCurrentFile = dir + "val.txt";
    	private static string valArchiveFile = dir + "val_archive.txt";
    	
    	private static string quotientCurrentFile = dir + "quotient.txt";
    	private static string quotientArchiveFile = dir + "quotient_archive.txt";
    	
    	private static string alarmCurrentFile = dir + "alarm.txt";
    	private static string alarmArchiveFile = dir + "alarm_archive.txt";
    	
    	private static string rawCurrentFile = dir + "raw.txt";
    	private static string rawArchiveFile = dir + "raw_archive.txt";    	
    	
    	private static string varsCurrentFile = dir + "vars.txt";
    	private static string varsArchiveFile = dir + "vars_archive.txt";
    	
    	public int Action()
    	{
        	lr.start_transaction("1_Preparation");
        	lr.start_transaction("2_CheckValue");
    		//
    		if (GetData())
    		{
    			if (CheckData())
    			{
        			lr.end_transaction("1_Preparation", lr.PASS);
		    		CalcData();
		    		EvalData(newVal);    				
    			}
	    		else
	    		{
	    			lr.end_transaction("1_Preparation", lr.FAIL);
        			lr.end_transaction("2_CheckValue", lr.PASS);
	    		}
    		}
    		else
    		{
    			lr.end_transaction("1_Preparation", lr.FAIL);
        		lr.end_transaction("2_CheckValue", lr.PASS);
    		}
    		//
    		return 0;
    	}
    	
        private bool GetData()
        {
        	// define connection data
        	string conStr = 
        		@"Data Source=SRVIWNSMPSCOM15\SCOMPRD22DWSQL;"
            	+ @"Initial Catalog=OperationsManagerDW;"
        		+ @"Integrated Security=true;"
            	+ @"Persist Security Info=true;"
            	+ @"Trusted_Connection=true;"
        		+ @"Connect Timeout=15;";
        	string queryStr = 
        		@"Use OperationsManagerDW; " +
                @"with basedata as (" +
	                @"select Path, FullName, ObjectName, CounterName, SampleValue, DateTime " +
		            @"from Perf.vPerfRaw pvpr " +
	                @"inner join vManagedEntity vme on pvpr.ManagedEntityRowId = vme.ManagedEntityRowId " +
	                @"inner join vPerformanceRuleInstance vpri on pvpr.PerformanceRuleInstanceRowId = vpri.PerformanceRuleInstanceRowId " +
	                @"inner join vPerformanceRule vpr on vpr.RuleRowId = vpri.RuleRowId " +
	                @"where CounterName = 'Count'" +
                @"), " +
                @"basedata_with_rank as (" +
                	@"select *, ROW_NUMBER() over (partition by FullName order by DateTime desc) rn " +
                	@"from basedata" +
                @") " +
                @"select * from basedata_with_rank where rn = 1 order by FullName;";
        	lr.output_message("Connection string: " + conStr);
        	lr.output_message("Query string: " + queryStr);
        	lr.output_message("==================================");  
        	//
        	// read data
    		try
		    {
	        	//
	        	// create con object
	        	System.Data.SqlClient.SqlConnection sqlCon = new SqlConnection(conStr);
	        	//
	        	// connect
				sqlCon.Open();
				SqlCommand cmd = new System.Data.SqlClient.SqlCommand(queryStr, sqlCon);
	    		SqlDataReader reader = cmd.ExecuteReader();
		        while (reader.Read())
		        {
		             lr.output_message(String.Format("{0};{1};{2}", reader["FullName"], reader["DateTime"], reader["SampleValue"]));// etc
		             string name = String.Format("{0}", reader["FullName"]);
		             string conn = String.Format("{0}", reader["SampleValue"]);
		             string time = String.Format("{0}", reader["DateTime"]);
		            _servers.Add(new HessenAccessServer(name, conn, time));
		        }
	        	reader.Close();
	        	return true;
		    }
    		catch (Exception exc)
    		{
    			return false;
    		}
        }
        
        private bool CheckData()
        {
        	if (_servers.Count > 0)
        	{
        		return true;
        	}
        	return false;
        }
    	
    	private void CalcData()
    	{
    		foreach (HessenAccessServer server in _servers)
    		{
    			if (server.Connections > 0)
    			{
    				newVal += server.Connections;
    			}
    		}
    	}
    	
        private void EvalData(int newVal)
        {
        	lastKnownStatus = ReadLog(lastKnownStatusFile);
        	int oldVal = ReadLog(valCurrentFile);
        	int oldAlarm = ReadLog(alarmCurrentFile);
        	int scenario;
        	int newAlarm;
    		double quotient = (double)newVal / (double)oldVal;
        	//
        	// scenarios that independently trigger events if both old and new values are valid
        	if (newVal >= 0 && oldVal >= 0) // if both values are valid
        	{
	        	if (oldAlarm == 0) // if the previous run did not yield an alarm, we have to validate there has not been a connection drop now
	        	{
	        		if (quotient < 0.7) // if the drop in connections is greater than 30%, create an alarm
	        		{
		        		newAlarm = 1;
		        		scenario = 1;
	        		}
	        		else // if the drop in connections smaller than 30%, no new alarm
	        		{
		        		newAlarm = 0;
		        		scenario = 2;
	        		}
	        	}
	        	else  // if the previous run did yield an alarm, we have to validate if there is a rise in connections by 30 percentage points
	        	{
	        		if (quotient < 1.3) // if false the previous alarm persists
	        		{
		        		newAlarm = 1;
		        		scenario = 3;
	        		}
	        		else // if true, we can clear the previous alarm
		        	{
		        		newAlarm = 0;
		        		scenario = 4;
		        	}
	        	}
	        	//
	        	// we set the last known status logfile
	        	lastKnownStatus = newAlarm;
    			lr.end_transaction("2_CheckValue", newAlarm);
        	}
        	//
        	// scenarios that retain old status because at least one value is not valid
        	else if (newVal >= 0 && oldVal < 0) // if the new value is valid after an invalid old value, we'll set the transaction to PASS
        	{
	        	quotient = -1;
        		newAlarm = 0;
        		scenario = 5;
	        	lastKnownStatus = newAlarm;
    			lr.end_transaction("2_CheckValue", newAlarm);
        	}
        	else if (newVal < 0 && oldVal < 0) // if the new value is invalid after an invalid old value, we'll retain the last known status
        	{
	        	quotient = -1;
        		newAlarm = lastKnownStatus;
        		scenario = 6;
    			lr.end_transaction("2_CheckValue", lastKnownStatus);
        	}
        	else if (newVal < 0 && oldVal >= 0) // if the new value is invalid after an valid old value, we'll retain the last alarm
        	{
	        	quotient = -1;
        		newAlarm = oldAlarm;
        		scenario = 7;
    			lr.end_transaction("2_CheckValue", oldAlarm);
        	}
        	//
        	// other scenarios
        	else // previously unknown scenarios go here for future development
        	{
        		quotient = -2;
        		newAlarm = 1;
        		scenario = 8;
    			lr.end_transaction("2_CheckValue", lr.FAIL);
        	}
        	//
        	lr.output_message("==================================");
        	lr.output_message("oldVal: " + oldVal.ToString());
        	lr.output_message("newVal: " + newVal.ToString());
        	lr.output_message("oldAlarm: " + oldAlarm.ToString());
        	lr.output_message("newAlarm: " + newAlarm.ToString());
        	lr.output_message("quotient: " + quotient.ToString());
        	lr.output_message("scenario: " + scenario.ToString());
        	//
        	WriteLog(newVal.ToString(), valCurrentFile, valArchiveFile);
        	StringBuilder sb = new StringBuilder();
        	foreach (HessenAccessServer server in _servers)
        	{
        		sb.AppendLine(server.Name + "," + server.ConnectionsStr + "," + server.Timestamp);
        	}
        	WriteLog(sb.ToString(), rawCurrentFile, rawArchiveFile);
        	WriteLog(quotient.ToString(), quotientCurrentFile, quotientArchiveFile);
        	WriteLog(newAlarm.ToString(), alarmCurrentFile, alarmArchiveFile);
        	WriteLog("oldVal: " + oldVal.ToString() + 
        	         "\nnewVal: " + newVal.ToString() + 
        	         "\noldAlarm: " + oldAlarm.ToString() + 
        	         "\nnewAlarm: " + newAlarm.ToString() + 
        	         "\nquotient: " + quotient.ToString() + 
        	         "\nscenario: " + scenario.ToString(),
        	         varsCurrentFile, varsArchiveFile);
			//
		}
        
        private int ReadLog(string file)
    	{
    		if (System.IO.File.Exists(file))
    		{
    			int oldVal = Int32.Parse(System.IO.File.ReadAllText(file));
    			System.IO.File.Delete(file);
    			return oldVal;
    		}
    		else
    		{
    			return -1;
    		}
    	}
    	
    	private void WriteLog(string output, string file, string archive1)
    	{
    		if (!Directory.Exists(dir))
    		{
    			Directory.CreateDirectory(dir);
    		}
    		System.IO.File.WriteAllText(file, output);
			System.IO.File.AppendAllText(archive1, "---------  " + DateTime.Now + "  ---------\n" + output + "\n");
			//
			// last known status
			System.IO.File.WriteAllText(lastKnownStatusFile, lastKnownStatus.ToString());
    	}
    }
}
