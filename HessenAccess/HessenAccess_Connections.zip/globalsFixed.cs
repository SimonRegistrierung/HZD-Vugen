//---------------------------------------------
//Script Title        :
//Script Description  :
//
//
//Recorder Version    : 
//---------------------------------------------

namespace Script
{
    public partial class VuserClass
    {
        private LoadRunner.LrApiWrapper lr = new LoadRunner.LrApiWrapper(); // Initialize LR-API Interface 
        private LoadRunner.VtsApi vts = new LoadRunner.VtsApi(); // Initialize VTS-API Interface 
        private LoadRunner.VtsMultiApi vts_multi = new LoadRunner.VtsMultiApi(); // Initialize VTS-MULTI-API Interface 
        public void DATASET_XML(int arg)
        {
        }
    }
}
