//---------------------------------------------
//Script Title        : FISBOX
//Script Description  : 
//
// Dr. Simon Beste
// 31.07.2025
//
// Neuentwicklung durch Probemigration 2025
//---------------------------------------------

namespace Script {
    using LoadRunner;
    using Mercury.LoadRunner.DotNetProtocol.Replay;
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Threading.Tasks;
    
    public partial class VuserClass {
        
    	private string _basePath = @"C:\HPBSM\Scripte\FISBOX\";
    	private int _timeout = 30;
		
    	private string RunPS(string environment)
    	{		
    		Process process = new Process();
    		process.StartInfo.FileName = @"powershell.exe";
			process.StartInfo.WorkingDirectory = _basePath + environment; // working dir	
			process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden; //Konsole wird sichbar dargestellt.
			process.StartInfo.UseShellExecute = false; // Muss auf false stehen, um die Ausf�hrung mit R�ckgaben ins vugen umleiten zu k�nnen
			process.StartInfo.RedirectStandardOutput = true; // Umleitung zu vugen
			process.StartInfo.RedirectStandardError = true; // Umleitung zu vugen
			process.StartInfo.CreateNoWindow = true;
			//
			process.StartInfo.Arguments = @"-ExecutionPolicy Bypass -File " + _basePath + environment + @"\KONSOLENTOOL\runVugen.ps1";
			lr.output_message(process.StartInfo.FileName + " " + process.StartInfo.Arguments);
			//
            Task<string> processTask = new Task<string>( () =>
            {
				//
				process.Start();
				process.WaitForExit();
				StreamReader readerOut = process.StandardOutput;
            	StreamReader readerErr = process.StandardError;
            	string outStr = readerOut.ReadToEnd();
            	string outErr = readerErr.ReadToEnd();
				//
				return outStr + "\n" + outErr;
            });
			//
        	processTask.Start();
			//
        	for (int i = 0; i < _timeout; i++)
			{				
				if (!processTask.IsCompleted)
				{
					lr.output_message("Iteration " + i + " of waiting for script to end.");
					System.Threading.Thread.Sleep(1000);
				}
				else
				{
					lr.output_message("Terminating PS environment");
					return processTask.Result;
				}
			}
			lr.output_message("Could not end PS environment in time!");
        	return "";
    	}
    	
        public int Action()
        {
        	lr.start_transaction(lr.eval_string("{Anwendung}_ALL"));
        	//
        	string output = RunPS(lr.eval_string("{Anwendung}"));
        	lr.output_message("PS Output:");
        	lr.output_message("----------");
        	lr.output_message(output);
        	lr.output_message("----------");
        	//
        	if (Regex.IsMatch(output, @"KONSOLENTOOL_EXITCODE \= (0|6)"))
    	    {
        		lr.output_message(lr.eval_string("{Anwendung}_ALL") + ": PASS");
        		lr.end_transaction(lr.eval_string("{Anwendung}_ALL"), lr.PASS);
    	    }
        	else
        	{
        		lr.output_message(lr.eval_string("{Anwendung}_ALL") + ": FAIL");
        		lr.end_transaction(lr.eval_string("{Anwendung}_ALL"), lr.FAIL);
        	}
            return 0;
        }
    }
}

