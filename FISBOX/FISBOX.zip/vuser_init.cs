
namespace Script
{
    public partial class VuserClass
    {
        public int vuser_init()
        {
        	if(false)
        	{
	        	lr.start_transaction("FISGW_ALL");
				lr.end_transaction("FISGW_ALL",lr.PASS);
				
	        	lr.start_transaction("VIFBOX_ALL");
				lr.end_transaction("VIFBOX_ALL",lr.PASS);
				
	        	lr.start_transaction("FISMGV_ALL");
				lr.end_transaction("FISMGV_ALL",lr.PASS);
        	}
        	return 0;
        }
    }
}

